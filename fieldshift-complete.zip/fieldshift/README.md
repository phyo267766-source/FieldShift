# FieldShift – Smart Crop Rotation Planner

A full-stack web application for Myanmar farmers to plan crop rotations using real NASA climate data. Built with React + Vite (frontend) and Python Flask (backend).

---

## Features

- **Farm Management** – Create, update, and manage farm profiles with location, soil type, crops, and irrigation
- **NASA Climate Data** – Fetch real historical climate data (temperature, rainfall, solar radiation, humidity) from NASA POWER API
- **Crop Rotation Engine** – Rule-based recommendation engine scoring rotations on diversity, soil health, water efficiency, and climate suitability
- **Plan Comparison** – Compare 3 rotation strategies side-by-side (traditional, diversified, water-optimized)
- **Farm Reports** – Generate comprehensive reports combining farm profile, climate data, and rotation recommendations
- **Demo Mode** – Clearly labeled fallback data when NASA API is unavailable
- **Bilingual** – English and Myanmar language support
- **Dark Mode** – Full dark theme support
- **Interactive Map** – Leaflet-based farm location picker

---

## Tech Stack

| Layer    | Technology                          |
|----------|-------------------------------------|
| Frontend | React 18.3, Vite 6.x, Tailwind CSS |
| Backend  | Python Flask 3.1, Flask-CORS 5.0   |
| Database | SQLite (Python built-in sqlite3)    |
| Climate  | NASA POWER API (free, no key)       |
| Charts   | Recharts                            |
| Map      | Leaflet via CDN                     |

---

## Project Structure

```
fieldshift/
├── backend/
│   ├── app.py                  # Flask app factory + entry point
│   ├── config.py               # Configuration (dev/prod)
│   ├── requirements.txt        # Python dependencies
│   ├── .env.example            # Environment variable template
│   ├── database/
│   │   ├── db.py               # Database helpers (connect, query, execute)
│   │   └── schema.sql          # Table definitions (farms, climate, rotations, reports)
│   ├── routes/
│   │   ├── farm_routes.py      # /api/farms CRUD
│   │   ├── climate_routes.py   # /api/climate/* endpoints
│   │   ├── rotation_routes.py  # /api/rotation/* endpoints
│   │   └── report_routes.py    # /api/reports endpoints
│   ├── services/
│   │   ├── nasa_service.py     # NASA POWER API client
│   │   ├── climate_service.py  # Climate analytics + caching
│   │   └── rotation_service.py # Crop rotation recommendation engine
│   ├── utils/
│   │   └── validators.py       # Input validation
│   └── tests/
│       └── test_api.py         # pytest test suite
├── src/
│   ├── api/
│   │   └── client.js           # Centralized API client
│   ├── components/             # Reusable React components
│   ├── contexts/
│   │   ├── FarmContext.jsx      # Farm state management (backend-connected)
│   │   ├── LocationContext.jsx  # GPS + location state
│   │   ├── ThemeContext.jsx     # Dark mode
│   │   └── LanguageContext.jsx  # i18n (en/mm)
│   ├── pages/
│   │   ├── Dashboard.jsx       # Home dashboard with climate stats
│   │   ├── MyFarm.jsx          # Farm profile form
│   │   ├── ClimateInsights.jsx # Climate charts + risk assessment
│   │   ├── CropRotation.jsx    # Rotation plan generator
│   │   ├── ComparePlans.jsx    # 3-plan comparison view
│   │   └── Reports.jsx         # Farm report generator
│   ├── data/
│   │   ├── mockData.js         # Fallback demo data
│   │   └── myanmarLocations.js # Location search data
│   └── App.jsx                 # Root component + routes
├── .env                        # Frontend env (VITE_API_BASE_URL)
├── index.html
├── vite.config.js
├── tailwind.config.js
└── package.json
```

---

## Run Locally (Windows + VS Code)

### Prerequisites

- **Node.js** 18+ → [nodejs.org](https://nodejs.org/)
- **Python** 3.10+ → [python.org](https://www.python.org/downloads/)
- **VS Code** → [code.visualstudio.com](https://code.visualstudio.com/)

### Step 1: Clone / Extract the Project

Extract the ZIP or clone the repository, then open the folder in VS Code.

### Step 2: Set Up the Backend

Open a **terminal** in VS Code (`` Ctrl+` ``):

```bash
# Navigate to backend
cd backend

# Create virtual environment
python -m venv venv

# Activate it (Windows PowerShell)
.\venv\Scripts\Activate.ps1

# If you get a PowerShell execution policy error, run:
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Or use Command Prompt instead:
# venv\Scripts\activate.bat

# Install Python dependencies
pip install -r requirements.txt

# Create your .env file
copy .env.example .env
```

### Step 3: Start the Backend

```bash
# Still in the backend/ directory with venv activated
python app.py
```

You should see:
```
 * Running on http://127.0.0.1:5000
```

Keep this terminal running.

### Step 4: Set Up the Frontend

Open a **second terminal** in VS Code (click the `+` icon):

```bash
# From the project root (fieldshift/)
npm install

# Start the dev server
npm run dev
```

You should see:
```
  VITE v6.x.x  ready
  ➜  Local:   http://localhost:5173/
```

### Step 5: Open the App

Open **http://localhost:5173** in your browser. The app will connect to the Flask backend automatically.

- **Green "Backend connected" badge** = connected to Flask + NASA data
- **Red "DEMO DATA" badge** = using fallback sample data

---

## API Endpoints

### Farms
| Method | Endpoint          | Description       |
|--------|-------------------|-------------------|
| GET    | /api/farms        | List all farms    |
| GET    | /api/farms/:id    | Get farm by ID    |
| POST   | /api/farms        | Create a farm     |
| PUT    | /api/farms/:id    | Update a farm     |
| DELETE | /api/farms/:id    | Delete a farm     |

### Climate
| Method | Endpoint                    | Description                  |
|--------|-----------------------------|------------------------------|
| GET    | /api/climate/farm/:id       | Daily climate for farm       |
| GET    | /api/climate/history/:id    | Monthly historical data      |
| GET    | /api/climate/summary/:id    | Climate summary + risks      |
| GET    | /api/climate/coordinates    | Climate by lat/lon           |

### Rotation
| Method | Endpoint                     | Description                |
|--------|------------------------------|----------------------------|
| POST   | /api/rotation/generate       | Generate rotation plan     |
| POST   | /api/rotation/compare        | Compare 3 plans            |
| GET    | /api/rotation/farm/:id       | Get plans for farm         |
| GET    | /api/rotation/:id            | Get specific plan          |
| PUT    | /api/rotation/:id/select     | Select a plan              |

### Reports
| Method | Endpoint              | Description           |
|--------|-----------------------|-----------------------|
| POST   | /api/reports          | Generate report       |
| GET    | /api/reports/farm/:id | Get farm's reports    |
| GET    | /api/reports/:id      | Get specific report   |

### Health
| Method | Endpoint      | Description    |
|--------|---------------|----------------|
| GET    | /api          | Service info   |
| GET    | /api/health   | Health check   |

---

## Running Tests

```bash
cd backend
# Activate your virtual environment first
pytest tests/test_api.py -v
```

---

## Environment Variables

### Frontend (.env)
```
VITE_API_BASE_URL=http://127.0.0.1:5000
```

### Backend (backend/.env)
```
FLASK_DEBUG=true
SECRET_KEY=your-secret-key-here
DATABASE_PATH=fieldshift.db
CLIMATE_CACHE_HOURS=24
```

---

## NASA POWER API

FieldShift uses NASA's POWER (Prediction Of Worldwide Energy Resources) API for real climate data. It's **free** and requires **no API key**.

- **Base URL:** `https://power.larc.nasa.gov/api/temporal`
- **Parameters:** Temperature (T2M), Precipitation (PRECTOTCORR), Solar Radiation (ALLSKY_SFC_SW_DWN), Humidity (RH2M), Wind Speed (WS2M)
- **Community:** AG (Agriculture)

When the NASA API is unreachable, the app falls back to **Demo Mode** with clearly labeled sample data.

---

## Important Notes

- Rotation scores are **illustrative** – based on a rule-based engine, not scientifically validated models
- Demo data is **clearly labeled** and never presented as real NASA data
- The backend uses **parameterized SQL queries** to prevent SQL injection
- Flask debug mode is **off by default** in production (controlled by FLASK_DEBUG env var)
- No authentication is required – this is a single-user local application
- Climate data is **cached in SQLite** to reduce API calls (configurable cache duration)

---

## License

Educational / personal project. NASA POWER data is freely available for public use.
