"""
Crop rotation API routes.
Endpoints for generating, comparing, and managing rotation plans.
"""
from flask import Blueprint, request, jsonify
from services.rotation_service import (
    generate_rotation_plan,
    generate_comparison,
    get_plans_for_farm,
    get_plan_by_id,
    select_plan,
)
from utils.validators import validate_rotation_request

rotation_bp = Blueprint('rotation', __name__)


@rotation_bp.route('/api/rotation/generate', methods=['POST'])
def generate_plan():
    """
    Generate a crop rotation plan.

    Body JSON:
      farm_id, current_crop, previous_crop, soil_type,
      water_availability, irrigation_method, planting_season, planning_period
    """
    data = request.get_json()
    is_valid, errors = validate_rotation_request(data)

    if not is_valid:
        return jsonify({'error': 'Validation failed.', 'details': errors}), 400

    result = generate_rotation_plan(
        farm_id=int(data['farm_id']),
        current_crop=data['current_crop'],
        previous_crop=data['previous_crop'],
        soil_type=data['soil_type'],
        water_availability=data.get('water_availability', 'Moderate'),
        irrigation_method=data.get('irrigation_method', 'Rain-fed'),
        planting_season=data.get('planting_season', 'Monsoon'),
        planning_period=int(data.get('planning_period', 3)),
    )

    if not result['success']:
        return jsonify(result), 400

    return jsonify(result), 201


@rotation_bp.route('/api/rotation/compare', methods=['POST'])
def compare_plans():
    """
    Generate 3 rotation plans for side-by-side comparison.

    Body JSON: same fields as /generate
    """
    data = request.get_json()
    is_valid, errors = validate_rotation_request(data)

    if not is_valid:
        return jsonify({'error': 'Validation failed.', 'details': errors}), 400

    result = generate_comparison(
        farm_id=int(data['farm_id']),
        current_crop=data['current_crop'],
        previous_crop=data['previous_crop'],
        soil_type=data['soil_type'],
        water_availability=data.get('water_availability', 'Moderate'),
        irrigation_method=data.get('irrigation_method', 'Rain-fed'),
        planting_season=data.get('planting_season', 'Monsoon'),
        planning_period=int(data.get('planning_period', 3)),
    )

    if not result['success']:
        return jsonify(result), 400

    return jsonify(result), 200


@rotation_bp.route('/api/rotation/farm/<int:farm_id>', methods=['GET'])
def farm_plans(farm_id):
    """Get all saved rotation plans for a farm."""
    result = get_plans_for_farm(farm_id)
    return jsonify(result), 200


@rotation_bp.route('/api/rotation/<int:plan_id>', methods=['GET'])
def get_plan(plan_id):
    """Get a specific rotation plan by ID."""
    result = get_plan_by_id(plan_id)
    if not result['success']:
        return jsonify(result), 404
    return jsonify(result), 200


@rotation_bp.route('/api/rotation/<int:plan_id>/select', methods=['PUT'])
def select_rotation_plan(plan_id):
    """Mark a rotation plan as the selected/preferred plan."""
    result = select_plan(plan_id)
    if not result['success']:
        return jsonify(result), 404
    return jsonify(result), 200
