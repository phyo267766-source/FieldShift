"""
Reports API routes.
Endpoints for generating and retrieving farm reports.
"""
import json
from flask import Blueprint, request, jsonify
from database.db import query_db, execute_db
from services.climate_service import get_climate_summary
from services.rotation_service import get_plans_for_farm

report_bp = Blueprint('reports', __name__)


@report_bp.route('/api/reports', methods=['POST'])
def create_report():
    """
    Generate a farm report combining climate, rotation, and farm data.

    Body JSON:
      farm_id (required)
      selected_plan_id (optional)
    """
    data = request.get_json()
    if not data or not data.get('farm_id'):
        return jsonify({'error': 'farm_id is required.'}), 400

    farm_id = int(data['farm_id'])
    selected_plan_id = data.get('selected_plan_id')

    # Get farm
    farm = query_db('SELECT * FROM farms WHERE id = ?', (farm_id,), one=True)
    if not farm:
        return jsonify({'error': 'Farm not found.'}), 404

    # Get climate summary
    climate = get_climate_summary(farm_id)

    # Get rotation plans
    plans = get_plans_for_farm(farm_id)

    # Get selected plan if specified
    selected_plan = None
    if selected_plan_id:
        selected_plan = query_db(
            'SELECT * FROM rotation_plans WHERE id = ?',
            (int(selected_plan_id),), one=True
        )
        if selected_plan:
            selected_plan['recommended_sequence'] = json.loads(selected_plan['recommended_sequence'])

    # Build report
    report_data = {
        'farm': {
            'name': farm['name'],
            'region': farm['region'],
            'country': farm['country'],
            'latitude': farm['latitude'],
            'longitude': farm['longitude'],
            'area': farm['area'],
            'area_unit': farm['area_unit'],
            'soil_type': farm['soil_type'],
            'current_crop': farm['current_crop'],
            'irrigation_method': farm['irrigation_method'],
        },
        'climate': {
            'summary': climate.get('summary', {}),
            'risks': climate.get('risks', []),
            'source': climate.get('source', 'Unavailable'),
            'demo_mode': climate.get('demo_mode', False),
        },
        'rotation': {
            'plans_count': plans.get('count', 0),
            'selected_plan': {
                'sequence': selected_plan['recommended_sequence'] if selected_plan else None,
                'score': selected_plan['suitability_score'] if selected_plan else None,
            } if selected_plan else None,
        },
        'recommendations': _build_recommendations(farm, climate, selected_plan),
    }

    # Save report
    report_id = execute_db(
        '''INSERT INTO reports (farm_id, selected_plan_id, report_type, report_data)
           VALUES (?, ?, ?, ?)''',
        (farm_id, selected_plan_id, 'farm_summary', json.dumps(report_data))
    )

    return jsonify({
        'message': 'Report generated successfully.',
        'report': {
            'id': report_id,
            'farm_id': farm_id,
            'data': report_data,
        },
    }), 201


@report_bp.route('/api/reports/farm/<int:farm_id>', methods=['GET'])
def farm_reports(farm_id):
    """Get all reports for a farm."""
    reports = query_db(
        'SELECT * FROM reports WHERE farm_id = ? ORDER BY created_at DESC',
        (farm_id,)
    )
    for r in reports:
        r['report_data'] = json.loads(r['report_data'])
    return jsonify({'reports': reports, 'count': len(reports)}), 200


@report_bp.route('/api/reports/<int:report_id>', methods=['GET'])
def get_report(report_id):
    """Get a specific report by ID."""
    report = query_db('SELECT * FROM reports WHERE id = ?', (report_id,), one=True)
    if not report:
        return jsonify({'error': 'Report not found.'}), 404
    report['report_data'] = json.loads(report['report_data'])
    return jsonify({'report': report}), 200


def _build_recommendations(farm, climate, selected_plan):
    """Build recommendation sections for the report."""
    recs = {}

    # Crop rotation recommendation
    if selected_plan:
        seq = selected_plan['recommended_sequence']
        recs['crop_rotation'] = {
            'title': 'Crop Rotation Recommendations',
            'plan': ' → '.join(seq),
            'score': selected_plan['suitability_score'],
            'note': 'Diversifying crops can help support soil health and reduce pest pressure.',
        }
    else:
        recs['crop_rotation'] = {
            'title': 'Crop Rotation Recommendations',
            'plan': f'{farm["current_crop"]} (no rotation plan selected)',
            'note': 'Generate a rotation plan to see alternative strategies.',
        }

    # Water conservation
    summary = climate.get('summary', {})
    rain = summary.get('rainfall', {})
    recs['water_conservation'] = {
        'title': 'Water Conservation Assessment',
        'value': f'{rain.get("total", "N/A")} mm total rainfall in period',
        'note': 'Monitor soil moisture and adjust irrigation timing based on rainfall patterns.',
    }

    # Soil management
    recs['soil_management'] = {
        'title': 'Soil Management Insights',
        'value': f'Soil type: {farm["soil_type"]}',
        'note': 'Retain crop residues and consider cover crops between main seasons.',
    }

    # Climate risk
    risks = climate.get('risks', [])
    high_risks = [r for r in risks if r.get('level') == 'High']
    if high_risks:
        recs['climate_risk'] = {
            'title': 'Climate Risk Summary',
            'value': f'{high_risks[0]["risk"]} — {high_risks[0]["level"]}',
            'note': high_risks[0].get('description', 'Monitor conditions closely.'),
        }
    else:
        recs['climate_risk'] = {
            'title': 'Climate Risk Summary',
            'value': 'No high-level risks detected',
            'note': 'Continue monitoring seasonal forecasts.',
        }

    return recs
