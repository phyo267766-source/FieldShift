"""
Climate data API routes.
Endpoints for fetching and analyzing NASA POWER climate data.
"""
from flask import Blueprint, request, jsonify
from services.climate_service import (
    get_climate_for_farm,
    get_climate_history,
    get_climate_summary,
)
from utils.validators import validate_coordinates

climate_bp = Blueprint('climate', __name__)


@climate_bp.route('/api/climate/farm/<int:farm_id>', methods=['GET'])
def farm_climate(farm_id):
    """
    Get daily climate data for a farm.

    Query params:
      start_date - YYYY-MM-DD (default: 6 months ago)
      end_date   - YYYY-MM-DD (default: yesterday)
      refresh    - 'true' to bypass cache
    """
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    force_refresh = request.args.get('refresh', 'false').lower() == 'true'

    result = get_climate_for_farm(
        farm_id,
        start_date=start_date,
        end_date=end_date,
        force_refresh=force_refresh,
    )

    if not result['success']:
        return jsonify(result), 404 if 'not found' in result.get('error', '').lower() else 500

    return jsonify(result), 200


@climate_bp.route('/api/climate/history/<int:farm_id>', methods=['GET'])
def climate_history(farm_id):
    """
    Get monthly historical climate data for a farm.

    Query params:
      start_year - int (default: 2 years ago)
      end_year   - int (default: last year)
    """
    start_year = request.args.get('start_year', type=int)
    end_year = request.args.get('end_year', type=int)

    result = get_climate_history(farm_id, start_year, end_year)

    if not result['success']:
        return jsonify(result), 404 if 'not found' in result.get('error', '').lower() else 500

    return jsonify(result), 200


@climate_bp.route('/api/climate/summary/<int:farm_id>', methods=['GET'])
def climate_summary(farm_id):
    """
    Get a high-level climate summary with risk assessment.
    """
    result = get_climate_summary(farm_id)

    if not result['success']:
        return jsonify(result), 404 if 'not found' in result.get('error', '').lower() else 500

    return jsonify(result), 200


@climate_bp.route('/api/climate/coordinates', methods=['GET'])
def climate_by_coordinates():
    """
    Get climate data for arbitrary coordinates (without saving a farm).

    Query params:
      lat        - latitude
      lon        - longitude
      start_date - YYYY-MM-DD
      end_date   - YYYY-MM-DD
    """
    lat = request.args.get('lat')
    lon = request.args.get('lon')

    if not lat or not lon:
        return jsonify({'error': 'lat and lon query parameters are required.'}), 400

    is_valid, error = validate_coordinates(lat, lon)
    if not is_valid:
        return jsonify({'error': error}), 400

    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    from services.nasa_service import fetch_daily_climate
    result = fetch_daily_climate(float(lat), float(lon), start_date, end_date)

    if not result['success']:
        return jsonify(result), 500

    return jsonify(result), 200
