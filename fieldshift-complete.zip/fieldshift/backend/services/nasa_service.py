"""
NASA POWER API integration service.

Fetches real historical climate data from NASA's POWER (Prediction of Worldwide
Energy Resources) API. This is a free, public API — no key required.

API docs: https://power.larc.nasa.gov/docs/services/api/

Parameters used:
  T2M        - Temperature at 2 Meters (°C)
  PRECTOTCORR - Precipitation Corrected (mm/day)
  ALLSKY_SFC_SW_DWN - All Sky Surface Shortwave Downward Irradiance (kWh/m²/day)
  RH2M       - Relative Humidity at 2 Meters (%)
  WS2M       - Wind Speed at 2 Meters (m/s)
"""
import requests
from datetime import datetime, timedelta
from config import Config


# NASA POWER parameters we request
POWER_PARAMETERS = 'T2M,PRECTOTCORR,ALLSKY_SFC_SW_DWN,RH2M,WS2M'

# Mapping from POWER parameter names to our field names
PARAM_MAP = {
    'T2M': 'temperature',
    'PRECTOTCORR': 'rainfall',
    'ALLSKY_SFC_SW_DWN': 'solar_radiation',
    'RH2M': 'humidity',
    'WS2M': 'wind_speed',
}


def fetch_daily_climate(latitude, longitude, start_date, end_date):
    """
    Fetch daily climate data from NASA POWER API.

    Args:
        latitude: Farm latitude (-90 to 90)
        longitude: Farm longitude (-180 to 180)
        start_date: Start date string 'YYYY-MM-DD'
        end_date: End date string 'YYYY-MM-DD'

    Returns:
        dict with 'success', 'data' (list of daily records), 'source', 'retrieved_at'
        On failure: dict with 'success': False, 'error' message
    """
    try:
        # Convert dates to POWER API format (YYYYMMDD)
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')

        # POWER API limit: max 366 days per request
        if (end_dt - start_dt).days > 366:
            end_dt = start_dt + timedelta(days=365)

        start_str = start_dt.strftime('%Y%m%d')
        end_str = end_dt.strftime('%Y%m%d')

        url = (
            f'{Config.NASA_POWER_BASE_URL}/daily/point'
            f'?parameters={POWER_PARAMETERS}'
            f'&community=AG'
            f'&longitude={longitude}'
            f'&latitude={latitude}'
            f'&start={start_str}'
            f'&end={end_str}'
            f'&format=JSON'
        )

        response = requests.get(url, timeout=Config.NASA_POWER_TIMEOUT)
        response.raise_for_status()
        result = response.json()

        # Parse the response
        properties = result.get('properties', {})
        parameters = properties.get('parameter', {})

        if not parameters:
            return {
                'success': False,
                'error': 'No data returned from NASA POWER for this location and date range.',
            }

        # Build daily records
        daily_records = []
        # Use T2M dates as the reference (all parameters share the same date keys)
        t2m_data = parameters.get('T2M', {})

        for date_key, temp_value in t2m_data.items():
            # date_key format: "YYYYMMDD"
            try:
                date_str = f'{date_key[:4]}-{date_key[4:6]}-{date_key[6:8]}'
            except (IndexError, ValueError):
                continue

            record = {
                'date': date_str,
                'temperature': _clean_value(temp_value),
                'rainfall': _clean_value(parameters.get('PRECTOTCORR', {}).get(date_key)),
                'solar_radiation': _clean_value(parameters.get('ALLSKY_SFC_SW_DWN', {}).get(date_key)),
                'humidity': _clean_value(parameters.get('RH2M', {}).get(date_key)),
                'wind_speed': _clean_value(parameters.get('WS2M', {}).get(date_key)),
            }
            daily_records.append(record)

        # Sort by date
        daily_records.sort(key=lambda r: r['date'])

        return {
            'success': True,
            'data': daily_records,
            'source': 'NASA POWER v2 — Prediction of Worldwide Energy Resources',
            'retrieved_at': datetime.utcnow().isoformat() + 'Z',
            'location': {'latitude': latitude, 'longitude': longitude},
            'period': {'start': start_date, 'end': end_date},
            'parameters': {
                'temperature': 'T2M — Air temperature at 2m (°C)',
                'rainfall': 'PRECTOTCORR — Precipitation corrected (mm/day)',
                'solar_radiation': 'ALLSKY_SFC_SW_DWN — Surface shortwave irradiance (kWh/m²/day)',
                'humidity': 'RH2M — Relative humidity at 2m (%)',
                'wind_speed': 'WS2M — Wind speed at 2m (m/s)',
            },
        }

    except requests.exceptions.Timeout:
        return {
            'success': False,
            'error': 'NASA POWER API request timed out. Please try again later.',
        }
    except requests.exceptions.ConnectionError:
        return {
            'success': False,
            'error': 'Could not connect to NASA POWER API. Check your internet connection.',
        }
    except requests.exceptions.HTTPError as e:
        return {
            'success': False,
            'error': f'NASA POWER API returned an error: {e.response.status_code}',
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Unexpected error fetching NASA data: {str(e)}',
        }


def fetch_monthly_climate(latitude, longitude, start_year, end_year):
    """
    Fetch monthly averaged climate data from NASA POWER API.

    Args:
        latitude: Farm latitude
        longitude: Farm longitude
        start_year: Start year (int)
        end_year: End year (int)

    Returns:
        dict with monthly averages per parameter
    """
    try:
        url = (
            f'{Config.NASA_POWER_BASE_URL}/monthly/point'
            f'?parameters={POWER_PARAMETERS}'
            f'&community=AG'
            f'&longitude={longitude}'
            f'&latitude={latitude}'
            f'&start={start_year}'
            f'&end={end_year}'
            f'&format=JSON'
        )

        response = requests.get(url, timeout=Config.NASA_POWER_TIMEOUT)
        response.raise_for_status()
        result = response.json()

        properties = result.get('properties', {})
        parameters = properties.get('parameter', {})

        if not parameters:
            return {
                'success': False,
                'error': 'No monthly data returned from NASA POWER.',
            }

        # Build monthly records
        # Keys are in format "YYYYMM" for monthly data
        monthly_records = []
        month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        t2m_data = parameters.get('T2M', {})

        for date_key, temp_value in t2m_data.items():
            if date_key == '13':  # Annual average key
                continue
            try:
                year = int(date_key[:4])
                month_num = int(date_key[4:6])
                if month_num < 1 or month_num > 12:
                    continue
                month_name = month_names[month_num - 1]
            except (IndexError, ValueError):
                continue

            record = {
                'year': year,
                'month': month_name,
                'month_num': month_num,
                'temperature': _clean_value(temp_value),
                'rainfall': _clean_value(parameters.get('PRECTOTCORR', {}).get(date_key)),
                'solar_radiation': _clean_value(parameters.get('ALLSKY_SFC_SW_DWN', {}).get(date_key)),
                'humidity': _clean_value(parameters.get('RH2M', {}).get(date_key)),
                'wind_speed': _clean_value(parameters.get('WS2M', {}).get(date_key)),
            }
            monthly_records.append(record)

        monthly_records.sort(key=lambda r: (r['year'], r['month_num']))

        return {
            'success': True,
            'data': monthly_records,
            'source': 'NASA POWER v2 — Monthly averages',
            'retrieved_at': datetime.utcnow().isoformat() + 'Z',
            'location': {'latitude': latitude, 'longitude': longitude},
            'period': {'start_year': start_year, 'end_year': end_year},
        }

    except requests.exceptions.Timeout:
        return {'success': False, 'error': 'NASA POWER API request timed out.'}
    except requests.exceptions.ConnectionError:
        return {'success': False, 'error': 'Could not connect to NASA POWER API.'}
    except Exception as e:
        return {'success': False, 'error': f'Error fetching monthly data: {str(e)}'}


def _clean_value(value):
    """
    Clean a NASA POWER value.
    POWER uses -999 or -999.0 for missing data.
    Returns None for missing values, rounded float otherwise.
    """
    if value is None:
        return None
    try:
        v = float(value)
        if v <= -999:
            return None
        return round(v, 2)
    except (TypeError, ValueError):
        return None
