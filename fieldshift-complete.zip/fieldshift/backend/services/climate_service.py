"""
Climate analytics service.

Calculates averages, trends, seasonal summaries, and risk indicators
from stored or freshly fetched NASA POWER climate data.
"""
import json
from datetime import datetime, timedelta
from database.db import query_db, execute_db
from services.nasa_service import fetch_daily_climate, fetch_monthly_climate
from config import Config


def get_climate_for_farm(farm_id, start_date=None, end_date=None, force_refresh=False):
    """
    Get climate data for a farm. Checks cache first, fetches from NASA if needed.

    Args:
        farm_id: The farm ID
        start_date: Start date 'YYYY-MM-DD' (defaults to 6 months ago)
        end_date: End date 'YYYY-MM-DD' (defaults to yesterday)
        force_refresh: If True, bypass cache and fetch fresh data

    Returns:
        dict with daily data, summary stats, and source info
    """
    # Get farm coordinates
    farm = query_db('SELECT * FROM farms WHERE id = ?', (farm_id,), one=True)
    if not farm:
        return {'success': False, 'error': 'Farm not found.'}

    # Default date range: last 6 months
    if not end_date:
        end_dt = datetime.utcnow() - timedelta(days=1)
        end_date = end_dt.strftime('%Y-%m-%d')
    if not start_date:
        start_dt = datetime.strptime(end_date, '%Y-%m-%d') - timedelta(days=180)
        start_date = start_dt.strftime('%Y-%m-%d')

    # Check cache
    if not force_refresh:
        cached = _get_cached_data(farm_id, start_date, end_date)
        if cached:
            summary = _calculate_summary(cached)
            return {
                'success': True,
                'data': cached,
                'summary': summary,
                'source': 'NASA POWER (cached)',
                'cached': True,
                'farm': {'id': farm['id'], 'name': farm['name']},
                'period': {'start': start_date, 'end': end_date},
            }

    # Fetch from NASA
    result = fetch_daily_climate(
        farm['latitude'], farm['longitude'], start_date, end_date
    )

    if not result['success']:
        # Return demo data as fallback with clear labeling
        demo = _generate_demo_data(start_date, end_date, farm['latitude'])
        summary = _calculate_summary(demo)
        return {
            'success': True,
            'data': demo,
            'summary': summary,
            'source': 'Demo data — NASA POWER was unavailable',
            'demo_mode': True,
            'nasa_error': result.get('error', 'Unknown error'),
            'farm': {'id': farm['id'], 'name': farm['name']},
            'period': {'start': start_date, 'end': end_date},
        }

    # Cache the data
    _cache_climate_data(farm_id, result['data'])

    summary = _calculate_summary(result['data'])
    return {
        'success': True,
        'data': result['data'],
        'summary': summary,
        'source': result['source'],
        'retrieved_at': result['retrieved_at'],
        'cached': False,
        'farm': {'id': farm['id'], 'name': farm['name']},
        'period': {'start': start_date, 'end': end_date},
    }


def get_climate_history(farm_id, start_year=None, end_year=None):
    """
    Get monthly historical climate data for a farm.

    Args:
        farm_id: The farm ID
        start_year: Start year (defaults to 2 years ago)
        end_year: End year (defaults to last year)

    Returns:
        dict with monthly data and summary
    """
    farm = query_db('SELECT * FROM farms WHERE id = ?', (farm_id,), one=True)
    if not farm:
        return {'success': False, 'error': 'Farm not found.'}

    current_year = datetime.utcnow().year
    if not end_year:
        end_year = current_year - 1
    if not start_year:
        start_year = end_year - 1

    result = fetch_monthly_climate(
        farm['latitude'], farm['longitude'], start_year, end_year
    )

    if not result['success']:
        return {
            'success': False,
            'error': result.get('error', 'Could not fetch historical data.'),
            'farm': {'id': farm['id'], 'name': farm['name']},
        }

    return {
        'success': True,
        'data': result['data'],
        'source': result['source'],
        'retrieved_at': result['retrieved_at'],
        'farm': {'id': farm['id'], 'name': farm['name']},
        'period': {'start_year': start_year, 'end_year': end_year},
    }


def get_climate_summary(farm_id):
    """
    Get a high-level climate summary for a farm.
    Uses cached data if available, otherwise fetches fresh.
    """
    climate = get_climate_for_farm(farm_id)
    if not climate['success']:
        return climate

    summary = climate.get('summary', {})
    risks = _assess_climate_risks(summary)
    seasonal = _get_seasonal_patterns(climate['data'])

    return {
        'success': True,
        'summary': summary,
        'risks': risks,
        'seasonal_patterns': seasonal,
        'source': climate.get('source', 'Unknown'),
        'demo_mode': climate.get('demo_mode', False),
        'farm': climate.get('farm'),
        'period': climate.get('period'),
    }


def _calculate_summary(data):
    """Calculate summary statistics from daily climate records."""
    if not data:
        return {}

    temps = [d['temperature'] for d in data if d.get('temperature') is not None]
    rains = [d['rainfall'] for d in data if d.get('rainfall') is not None]
    solars = [d['solar_radiation'] for d in data if d.get('solar_radiation') is not None]
    humids = [d['humidity'] for d in data if d.get('humidity') is not None]

    summary = {
        'record_count': len(data),
        'date_range': {
            'start': data[0]['date'] if data else None,
            'end': data[-1]['date'] if data else None,
        },
    }

    if temps:
        summary['temperature'] = {
            'average': round(sum(temps) / len(temps), 1),
            'min': round(min(temps), 1),
            'max': round(max(temps), 1),
            'unit': '°C',
        }

    if rains:
        summary['rainfall'] = {
            'total': round(sum(rains), 1),
            'average_daily': round(sum(rains) / len(rains), 1),
            'max_daily': round(max(rains), 1),
            'rainy_days': sum(1 for r in rains if r > 1.0),
            'unit': 'mm',
        }

    if solars:
        summary['solar_radiation'] = {
            'average': round(sum(solars) / len(solars), 1),
            'unit': 'kWh/m²/day',
        }

    if humids:
        summary['humidity'] = {
            'average': round(sum(humids) / len(humids), 1),
            'unit': '%',
        }

    return summary


def _assess_climate_risks(summary):
    """Assess climate risks based on summary statistics."""
    risks = []

    temp = summary.get('temperature', {})
    if temp:
        avg_t = temp.get('average', 0)
        max_t = temp.get('max', 0)
        if max_t > 38:
            risks.append({
                'risk': 'Heat stress',
                'level': 'High',
                'description': f'Maximum temperature reached {max_t}°C. '
                               f'Protect heat-sensitive crop phases.',
            })
        elif max_t > 35:
            risks.append({
                'risk': 'Heat stress',
                'level': 'Moderate',
                'description': f'Some warm days above 35°C detected. '
                               f'Monitor crop stress indicators.',
            })
        else:
            risks.append({
                'risk': 'Heat stress',
                'level': 'Low',
                'description': 'Temperature within comfortable range for most crops.',
            })

    rain = summary.get('rainfall', {})
    if rain:
        total = rain.get('total', 0)
        max_daily = rain.get('max_daily', 0)
        if max_daily > 80:
            risks.append({
                'risk': 'Heavy rainfall risk',
                'level': 'High',
                'description': f'Extreme daily rainfall of {max_daily} mm recorded. '
                               f'Check drainage and flood-prone areas.',
            })
        elif max_daily > 50:
            risks.append({
                'risk': 'Heavy rainfall risk',
                'level': 'Moderate',
                'description': f'Significant rainfall events detected. '
                               f'Track flood-prone areas during the production window.',
            })
        else:
            risks.append({
                'risk': 'Heavy rainfall risk',
                'level': 'Low',
                'description': 'No extreme rainfall events detected in this period.',
            })

        avg_daily = rain.get('average_daily', 0)
        if avg_daily < 1.0 and total < 200:
            risks.append({
                'risk': 'Drought risk',
                'level': 'High',
                'description': f'Very low rainfall ({total} mm total). '
                               f'Irrigation is likely essential.',
            })
        elif avg_daily < 3.0:
            risks.append({
                'risk': 'Drought risk',
                'level': 'Moderate',
                'description': 'Below-average rainfall. Monitor soil moisture closely.',
            })
        else:
            risks.append({
                'risk': 'Drought risk',
                'level': 'Low',
                'description': 'Adequate rainfall for most crops.',
            })

    return risks


def _get_seasonal_patterns(data):
    """Group daily data into seasonal summaries."""
    if not data:
        return []

    # Group by month
    monthly = {}
    for record in data:
        try:
            dt = datetime.strptime(record['date'], '%Y-%m-%d')
            month_key = dt.strftime('%Y-%m')
            month_name = dt.strftime('%b')
        except (ValueError, KeyError):
            continue

        if month_key not in monthly:
            monthly[month_key] = {
                'month': month_name,
                'year_month': month_key,
                'temps': [],
                'rains': [],
                'solars': [],
            }

        if record.get('temperature') is not None:
            monthly[month_key]['temps'].append(record['temperature'])
        if record.get('rainfall') is not None:
            monthly[month_key]['rains'].append(record['rainfall'])
        if record.get('solar_radiation') is not None:
            monthly[month_key]['solars'].append(record['solar_radiation'])

    # Calculate monthly averages
    result = []
    for key in sorted(monthly.keys()):
        m = monthly[key]
        entry = {'month': m['month'], 'year_month': m['year_month']}
        if m['temps']:
            entry['avg_temperature'] = round(sum(m['temps']) / len(m['temps']), 1)
        if m['rains']:
            entry['total_rainfall'] = round(sum(m['rains']), 1)
        if m['solars']:
            entry['avg_solar'] = round(sum(m['solars']) / len(m['solars']), 1)
        result.append(entry)

    return result


def _get_cached_data(farm_id, start_date, end_date):
    """Check if we have recent cached climate data for this farm and date range."""
    cache_limit = Config.CLIMATE_CACHE_HOURS
    rows = query_db(
        '''SELECT observation_date as date, temperature, rainfall,
                  solar_radiation, humidity, wind_speed, data_source, retrieved_at
           FROM climate_data
           WHERE farm_id = ?
             AND observation_date >= ?
             AND observation_date <= ?
             AND retrieved_at >= datetime('now', ?)
           ORDER BY observation_date''',
        (farm_id, start_date, end_date, f'-{cache_limit} hours')
    )

    if not rows or len(rows) < 5:
        return None

    return rows


def _cache_climate_data(farm_id, daily_data):
    """Store fetched climate data in the database for caching."""
    from database.db import get_connection
    conn = get_connection()
    try:
        # Remove old cached data for this farm in this date range
        if daily_data:
            dates = [d['date'] for d in daily_data]
            conn.execute(
                'DELETE FROM climate_data WHERE farm_id = ? AND observation_date >= ? AND observation_date <= ?',
                (farm_id, min(dates), max(dates))
            )

        for record in daily_data:
            conn.execute(
                '''INSERT INTO climate_data
                   (farm_id, observation_date, temperature, rainfall,
                    solar_radiation, humidity, wind_speed, data_source)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                (
                    farm_id,
                    record['date'],
                    record.get('temperature'),
                    record.get('rainfall'),
                    record.get('solar_radiation'),
                    record.get('humidity'),
                    record.get('wind_speed'),
                    'NASA POWER',
                )
            )
        conn.commit()
    finally:
        conn.close()


def _generate_demo_data(start_date, end_date, latitude):
    """
    Generate clearly labeled demo data when NASA POWER is unavailable.
    Uses realistic seasonal patterns based on latitude (tropical Myanmar).
    """
    import random
    random.seed(42)  # Reproducible demo data

    start_dt = datetime.strptime(start_date, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date, '%Y-%m-%d')

    data = []
    current = start_dt
    while current <= end_dt:
        month = current.month
        # Seasonal patterns for tropical Myanmar
        # Monsoon: May-Oct (high rain, moderate temp)
        # Cool dry: Nov-Feb (low rain, cooler)
        # Hot dry: Mar-Apr (low rain, hot)
        if month in (5, 6, 7, 8, 9, 10):
            base_temp = 28.0 + random.uniform(-2, 2)
            base_rain = random.uniform(3, 15)
            base_solar = random.uniform(3.5, 5.5)
        elif month in (11, 12, 1, 2):
            base_temp = 24.0 + random.uniform(-2, 3)
            base_rain = random.uniform(0, 2)
            base_solar = random.uniform(5.0, 6.5)
        else:
            base_temp = 32.0 + random.uniform(-2, 3)
            base_rain = random.uniform(0, 3)
            base_solar = random.uniform(5.5, 7.0)

        data.append({
            'date': current.strftime('%Y-%m-%d'),
            'temperature': round(base_temp, 1),
            'rainfall': round(base_rain, 1),
            'solar_radiation': round(base_solar, 1),
            'humidity': round(random.uniform(55, 90), 1),
            'wind_speed': round(random.uniform(0.5, 4.0), 1),
        })
        current += timedelta(days=1)

    return data
