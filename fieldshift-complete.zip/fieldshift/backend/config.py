"""
FieldShift Backend Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Base configuration."""
    SECRET_KEY = os.getenv('SECRET_KEY', 'fieldshift-dev-key-change-in-production')
    DATABASE_PATH = os.getenv('DATABASE_PATH', os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'database', 'fieldshift.db'
    ))

    # NASA POWER API (free, no key required)
    NASA_POWER_BASE_URL = 'https://power.larc.nasa.gov/api/temporal'
    NASA_POWER_TIMEOUT = 30  # seconds

    # CORS settings
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173').split(',')

    # Cache settings
    CLIMATE_CACHE_HOURS = int(os.getenv('CLIMATE_CACHE_HOURS', '24'))

    DEBUG = os.getenv('FLASK_DEBUG', 'false').lower() == 'true'


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}
