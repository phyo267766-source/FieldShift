-- FieldShift Database Schema
-- SQLite database for farm, climate, rotation, and report data

CREATE TABLE IF NOT EXISTS farms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    country TEXT NOT NULL DEFAULT 'Myanmar',
    region TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    area REAL NOT NULL DEFAULT 1.0,
    area_unit TEXT NOT NULL DEFAULT 'hectares',
    soil_type TEXT NOT NULL DEFAULT 'Clay loam',
    current_crop TEXT NOT NULL DEFAULT 'Rice',
    previous_crop TEXT NOT NULL DEFAULT 'Rice',
    irrigation_method TEXT NOT NULL DEFAULT 'Rain-fed',
    planting_season TEXT NOT NULL DEFAULT 'Monsoon',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS climate_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL,
    observation_date TEXT NOT NULL,
    temperature REAL,
    rainfall REAL,
    solar_radiation REAL,
    humidity REAL,
    wind_speed REAL,
    data_source TEXT NOT NULL DEFAULT 'NASA POWER',
    retrieved_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (farm_id) REFERENCES farms(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rotation_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL,
    current_crop TEXT NOT NULL,
    previous_crop TEXT NOT NULL,
    soil_type TEXT NOT NULL,
    water_availability TEXT NOT NULL DEFAULT 'Moderate',
    irrigation_method TEXT NOT NULL DEFAULT 'Rain-fed',
    planting_season TEXT NOT NULL DEFAULT 'Monsoon',
    planning_period INTEGER NOT NULL DEFAULT 3,
    recommended_sequence TEXT NOT NULL,
    suitability_score REAL NOT NULL DEFAULT 0,
    explanation TEXT,
    season_details TEXT,
    benefits TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL,
    selected_plan_id INTEGER,
    report_type TEXT NOT NULL DEFAULT 'farm_summary',
    report_data TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (farm_id) REFERENCES farms(id) ON DELETE CASCADE,
    FOREIGN KEY (selected_plan_id) REFERENCES rotation_plans(id) ON DELETE SET NULL
);

-- Index for faster climate data lookups
CREATE INDEX IF NOT EXISTS idx_climate_farm_date
    ON climate_data(farm_id, observation_date);

-- Index for rotation plans by farm
CREATE INDEX IF NOT EXISTS idx_rotation_farm
    ON rotation_plans(farm_id);

-- Index for reports by farm
CREATE INDEX IF NOT EXISTS idx_reports_farm
    ON reports(farm_id);
