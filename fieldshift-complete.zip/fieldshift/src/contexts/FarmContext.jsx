import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { farmApi } from '../api/client';

const FarmContext = createContext(null);

const DEFAULT_FARM = {
  name: 'Shwe Pyi Farm',
  country: 'Myanmar',
  region: 'Ayeyarwady',
  latitude: 16.77,
  longitude: 94.73,
  area: 12.5,
  area_unit: 'hectares',
  soil_type: 'Clay loam',
  current_crop: 'Rice',
  previous_crop: 'Rice',
  irrigation_method: 'Canal irrigation',
  planting_season: 'Monsoon',
};

export function FarmProvider({ children }) {
  const [farms, setFarms] = useState([]);
  const [currentFarm, setCurrentFarm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [backendAvailable, setBackendAvailable] = useState(true);

  // Load farms from backend on mount
  useEffect(() => {
    loadFarms();
  }, []);

  const loadFarms = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await farmApi.getAll();
      setFarms(data.farms || []);
      setBackendAvailable(true);
      // Set current farm to the first one, or null
      if (data.farms && data.farms.length > 0) {
        setCurrentFarm(data.farms[0]);
      } else {
        setCurrentFarm(null);
      }
    } catch (err) {
      console.warn('Backend not available, using local mode:', err.message);
      setBackendAvailable(false);
      // Fallback: load from localStorage
      try {
        const saved = localStorage.getItem('fieldshift_farm');
        if (saved) {
          const farmData = JSON.parse(saved);
          setCurrentFarm({ id: null, ...DEFAULT_FARM, ...farmData });
        } else {
          setCurrentFarm({ id: null, ...DEFAULT_FARM });
        }
      } catch {
        setCurrentFarm({ id: null, ...DEFAULT_FARM });
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const saveFarm = useCallback(async (farmData) => {
    setError(null);
    try {
      if (backendAvailable) {
        if (currentFarm && currentFarm.id) {
          // Update existing farm
          const data = await farmApi.update(currentFarm.id, farmData);
          setCurrentFarm(data.farm);
          await loadFarms();
          return data.farm;
        } else {
          // Create new farm
          const data = await farmApi.create(farmData);
          setCurrentFarm(data.farm);
          await loadFarms();
          return data.farm;
        }
      } else {
        // Fallback: save to localStorage
        localStorage.setItem('fieldshift_farm', JSON.stringify(farmData));
        setCurrentFarm({ id: null, ...farmData });
        return { id: null, ...farmData };
      }
    } catch (err) {
      setError(err.message);
      // Still save locally as backup
      try {
        localStorage.setItem('fieldshift_farm', JSON.stringify(farmData));
      } catch {}
      throw err;
    }
  }, [backendAvailable, currentFarm, loadFarms]);

  const deleteFarm = useCallback(async (farmId) => {
    if (!backendAvailable || !farmId) return;
    try {
      await farmApi.delete(farmId);
      await loadFarms();
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [backendAvailable, loadFarms]);

  const selectFarm = useCallback((farm) => {
    setCurrentFarm(farm);
  }, []);

  return (
    <FarmContext.Provider value={{
      farms,
      currentFarm,
      loading,
      error,
      backendAvailable,
      saveFarm,
      deleteFarm,
      selectFarm,
      loadFarms,
    }}>
      {children}
    </FarmContext.Provider>
  );
}

export function useFarm() {
  const ctx = useContext(FarmContext);
  if (!ctx) throw new Error('useFarm must be used within FarmProvider');
  return ctx;
}
