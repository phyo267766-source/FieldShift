import { createContext, useContext, useState, useEffect, useCallback } from 'react';

const LocationContext = createContext(null);

const DEFAULT_LOCATION = {
  lat: 16.77,
  lon: 94.73,
  name: 'Shwe Pyi Farm',
  region: 'Ayeyarwady',
  township: '',
  fullAddress: 'Ayeyarwady, Myanmar',
};

export function LocationProvider({ children }) {
  const [location, setLocationState] = useState(() => {
    try {
      const saved = localStorage.getItem('fieldshift_location');
      return saved ? JSON.parse(saved) : DEFAULT_LOCATION;
    } catch {
      return DEFAULT_LOCATION;
    }
  });

  const [gpsTracking, setGpsTracking] = useState(false);
  const [gpsWatchId, setGpsWatchId] = useState(null);

  const setLocation = useCallback((loc) => {
    const updated = { ...location, ...loc };
    setLocationState(updated);
    try {
      localStorage.setItem('fieldshift_location', JSON.stringify(updated));
    } catch {}
  }, [location]);

  const startGpsTracking = useCallback(() => {
    if (!navigator.geolocation) return;
    setGpsTracking(true);
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        setLocation({
          lat: parseFloat(pos.coords.latitude.toFixed(4)),
          lon: parseFloat(pos.coords.longitude.toFixed(4)),
          name: 'GPS Location',
          fullAddress: 'Current GPS position',
        });
      },
      (err) => console.warn('GPS error:', err.message),
      { enableHighAccuracy: true, maximumAge: 30000 }
    );
    setGpsWatchId(id);
  }, [setLocation]);

  const stopGpsTracking = useCallback(() => {
    if (gpsWatchId !== null) {
      navigator.geolocation.clearWatch(gpsWatchId);
      setGpsWatchId(null);
    }
    setGpsTracking(false);
  }, [gpsWatchId]);

  const detectCurrentLocation = useCallback(() => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const lat = parseFloat(pos.coords.latitude.toFixed(4));
          const lon = parseFloat(pos.coords.longitude.toFixed(4));
          // Reverse geocode
          try {
            const res = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&addressdetails=1`,
              { headers: { 'Accept-Language': 'en' } }
            );
            const data = await res.json();
            const addr = data.address || {};
            const loc = {
              lat, lon,
              name: addr.village || addr.town || addr.city || 'GPS Location',
              region: addr.state || addr.county || '',
              township: addr.town || addr.suburb || '',
              fullAddress: data.display_name || 'Current GPS position',
            };
            setLocation(loc);
            resolve(loc);
          } catch {
            const loc = { lat, lon, name: 'GPS Location', fullAddress: 'Current GPS position' };
            setLocation(loc);
            resolve(loc);
          }
        },
        (err) => reject(err),
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });
  }, [setLocation]);

  useEffect(() => {
    return () => {
      if (gpsWatchId !== null) {
        navigator.geolocation.clearWatch(gpsWatchId);
      }
    };
  }, [gpsWatchId]);

  return (
    <LocationContext.Provider value={{
      location,
      setLocation,
      gpsTracking,
      startGpsTracking,
      stopGpsTracking,
      detectCurrentLocation,
    }}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const ctx = useContext(LocationContext);
  if (!ctx) throw new Error('useLocation must be used within LocationProvider');
  return ctx;
}
