import { useState } from 'react';
import { ArrowRight, Leaf, FileText, Plus, Loader2, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocation } from '../contexts/LocationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import { rotationApi } from '../api/client';
import { rotationPlan as mockRotationPlan } from '../data/mockData';

function CropCard({ card }) {
  return (
    <div className="card flex flex-col">
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{card.season}</p>
      <h4 className="text-xl font-bold text-gray-900 dark:text-gray-100 mt-1">{card.crop}</h4>
      <p className="text-sm text-gray-500 mt-0.5">{card.period}</p>

      {/* Crop icon */}
      <div className="mt-3 mb-3 h-28 bg-amber-50 dark:bg-amber-900/20 rounded-lg flex items-center justify-center overflow-hidden">
        <div className="text-4xl">{card.icon || <Leaf className="w-10 h-10 text-brand-500" />}</div>
      </div>

      <div className="space-y-2 mt-auto text-sm">
        <div>
          <p className="text-xs text-gray-400 uppercase">Water demand</p>
          <p className="text-gray-700 dark:text-gray-300">{card.rainfall || card.water_demand || 'N/A'}</p>
        </div>
        <div>
          <p className="text-xs text-gray-400 uppercase">Soil benefit</p>
          <p className="text-gray-700 dark:text-gray-300">{card.soilHealth || card.soil_benefit || 'N/A'}</p>
        </div>
        <div>
          <p className="text-xs text-gray-400 uppercase">Climate suitability</p>
          <p className="text-gray-700 dark:text-gray-300 font-medium">{card.suitability || card.climate_suitability || 'N/A'}</p>
        </div>
      </div>
    </div>
  );
}

export default function CropRotation() {
  const { location } = useLocation();
  const { t } = useLanguage();
  const { currentFarm, backendAvailable } = useFarm();

  const [currentCrop, setCurrentCrop] = useState('Rice');
  const [previousCrop, setPreviousCrop] = useState('Rice');
  const [soilType, setSoilType] = useState('Clay loam');
  const [mode, setMode] = useState('Moderate');
  const [season, setSeason] = useState('Monsoon');
  const [planningPeriod, setPlanningPeriod] = useState('3');
  const [waterAvailability, setWaterAvailability] = useState('Moderate');

  const [showPlan, setShowPlan] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);

  // Plan data — start with mock, replace with backend data
  const [plan, setPlan] = useState(mockRotationPlan);
  const [isBackendPlan, setIsBackendPlan] = useState(false);

  const generatePlan = async () => {
    setGenerating(true);
    setError(null);

    if (!backendAvailable || !currentFarm) {
      // Fallback to mock
      setPlan(mockRotationPlan);
      setIsBackendPlan(false);
      setShowPlan(true);
      setGenerating(false);
      return;
    }

    try {
      const res = await rotationApi.generate({
        farm_id: currentFarm.id,
        current_crop: currentCrop,
        previous_crop: previousCrop,
        soil_type: soilType,
        season: season,
        num_seasons: parseInt(planningPeriod),
        water_availability: waterAvailability,
      });

      const data = res.data;

      // Transform backend response to match the card structure
      const cards = (data.season_details || []).map(s => ({
        season: s.season_name || s.season,
        crop: s.crop,
        period: s.period || `${s.season_name}`,
        icon: s.icon || '🌱',
        rainfall: s.water_demand || 'N/A',
        soilHealth: s.soil_benefit || 'N/A',
        suitability: s.climate_suitability || 'Good',
      }));

      const transformedPlan = {
        title: data.plan_name || `${currentCrop} → Diversified Rotation`,
        farmName: currentFarm.name,
        seasons: data.num_seasons || parseInt(planningPeriod),
        dateRange: data.date_range || '2026–2027',
        sequence: data.sequence || cards.map(c => c.crop),
        cards: cards.length > 0 ? cards : mockRotationPlan.cards,
        benefits: data.benefits || mockRotationPlan.benefits,
        score: data.score,
        explanation: data.explanation,
      };

      setPlan(transformedPlan);
      setIsBackendPlan(true);
      setShowPlan(true);
    } catch (err) {
      console.warn('Rotation generation failed:', err.message);
      setError('Could not generate plan from backend. Showing example plan.');
      setPlan(mockRotationPlan);
      setIsBackendPlan(false);
      setShowPlan(true);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Header */}
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('planForBest')}</p>
      <h1 className="page-header mt-1">{t('smartCropRotation')}</h1>
      <p className="page-subtitle">{t('planHealthier')}</p>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-8">
        {/* Left sidebar: Growing conditions */}
        <div className="lg:col-span-1">
          <h2 className="section-title mb-4">{t('yourGrowingConditions')}</h2>
          <div className="space-y-4">
            <div>
              <label className="label">Select farm</label>
              <select className="select-field" defaultValue={currentFarm?.name || location.name}>
                <option>{currentFarm?.name || location.name}</option>
              </select>
            </div>
            <div>
              <label className="label">Current crop</label>
              <select className="select-field" value={currentCrop} onChange={e => setCurrentCrop(e.target.value)}>
                <option>Rice</option>
                <option>Wheat</option>
                <option>Maize</option>
                <option>Mung Bean</option>
                <option>Soybean</option>
                <option>Sesame</option>
                <option>Groundnut</option>
              </select>
            </div>
            <div>
              <label className="label">Previous crop</label>
              <select className="select-field" value={previousCrop} onChange={e => setPreviousCrop(e.target.value)}>
                <option>Rice</option>
                <option>Wheat</option>
                <option>Maize</option>
                <option>Mung Bean</option>
                <option>Soybean</option>
                <option>Sesame</option>
                <option>Groundnut</option>
              </select>
            </div>
            <div>
              <label className="label">Soil type</label>
              <select className="select-field" value={soilType} onChange={e => setSoilType(e.target.value)}>
                <option>Clay loam</option>
                <option>Sandy loam</option>
                <option>Silt loam</option>
                <option>Clay</option>
                <option>Sandy</option>
                <option>Loam</option>
              </select>
            </div>
            <div>
              <label className="label">Water availability</label>
              <select className="select-field" value={waterAvailability} onChange={e => setWaterAvailability(e.target.value)}>
                <option>Low</option>
                <option>Moderate</option>
                <option>High</option>
              </select>
            </div>
            <div>
              <label className="label">Preferred planting season</label>
              <select className="select-field" value={season} onChange={e => setSeason(e.target.value)}>
                <option value="Monsoon">Monsoon • May–Oct</option>
                <option value="Winter">Winter • Nov–Feb</option>
                <option value="Summer">Summer • Mar–May</option>
              </select>
            </div>
            <div>
              <label className="label">Planning period</label>
              <select className="select-field" value={planningPeriod} onChange={e => setPlanningPeriod(e.target.value)}>
                <option value="2">2 seasons</option>
                <option value="3">3 seasons</option>
                <option value="4">4 seasons</option>
              </select>
            </div>
          </div>

          <button
            onClick={generatePlan}
            disabled={generating}
            className="btn-primary w-full mt-6 justify-center"
          >
            {generating ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</>
            ) : (
              <>Generate Rotation Plan <ArrowRight className="w-4 h-4" /></>
            )}
          </button>
          <p className="text-[10px] text-gray-400 mt-2 text-center">
            {backendAvailable
              ? 'Scored using rule-based engine. Scores are illustrative.'
              : 'Backend not connected. Showing example plan.'}
          </p>

          {error && (
            <div className="flex items-center gap-2 mt-3 text-xs text-amber-600 dark:text-amber-400">
              <AlertCircle className="w-3 h-3 shrink-0" />
              {error}
            </div>
          )}
        </div>

        {/* Right: Rotation plan */}
        <div className="lg:col-span-3">
          {showPlan && (
            <>
              {/* Plan header */}
              <div className="mb-6">
                <p className="text-xs font-medium text-forest uppercase tracking-wider">
                  {isBackendPlan ? '✦ Generated plan' : '✦ Example plan – Ready to explore'}
                </p>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">{plan.title}</h2>
                <p className="text-sm text-gray-500 mt-0.5">
                  {plan.farmName} • {plan.seasons} seasons • {plan.dateRange}
                </p>

                {/* Score badge */}
                {isBackendPlan && plan.score != null && (
                  <div className="inline-flex items-center gap-1 mt-2 px-2 py-1 bg-green-50 dark:bg-green-900/30 rounded text-xs font-medium text-green-700 dark:text-green-400">
                    Score: {typeof plan.score === 'number' ? plan.score.toFixed(1) : plan.score}/100 (illustrative)
                  </div>
                )}

                {/* Sequence flow */}
                <div className="flex items-center gap-2 mt-3 text-sm font-medium text-gray-700 dark:text-gray-300 flex-wrap">
                  {plan.sequence.map((crop, i) => (
                    <span key={i} className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1">
                        <span className="w-5 h-5 rounded-full bg-forest text-white text-xs flex items-center justify-center font-bold">
                          {i + 1}
                        </span>
                        {crop}
                      </span>
                      {i < plan.sequence.length - 1 && (
                        <ArrowRight className="w-4 h-4 text-gray-300" />
                      )}
                    </span>
                  ))}
                </div>
              </div>

              {/* Crop cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                {plan.cards.map((card, i) => (
                  <CropCard key={i} card={card} />
                ))}
              </div>

              {/* Explanation (backend plans) */}
              {isBackendPlan && plan.explanation && (
                <div className="card mb-6">
                  <h3 className="section-title mb-2">Plan Rationale</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{plan.explanation}</p>
                </div>
              )}

              {/* Benefits */}
              <div className="card mb-6">
                <h3 className="section-title mb-1">Why This Rotation</h3>
                <p className="text-sm text-gray-500 mb-4">Different crops, complementary benefits.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(Array.isArray(plan.benefits) ? plan.benefits : []).map((b, i) => (
                    <div key={b.id || i} className="flex gap-3">
                      <span className="text-xs font-bold text-forest mt-0.5">{b.id || `0${i+1}`}</span>
                      <div>
                        <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{b.title}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{b.desc || b.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap items-center gap-3">
                <Link to="/compare-plans" className="btn-primary">
                  Compare rotation plans <ArrowRight className="w-4 h-4" />
                </Link>
                <button className="btn-outline">
                  <FileText className="w-4 h-4" />
                  View plan report
                </button>
                <button onClick={() => { setPlan(mockRotationPlan); setShowPlan(false); setIsBackendPlan(false); }} className="btn-outline">
                  <Plus className="w-4 h-4" />
                  Start new plan
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
