import { useState, useEffect } from 'react';
import { ArrowRight, Save, RefreshCw, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocation } from '../contexts/LocationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import InteractiveMap from '../components/InteractiveMap';
import { farmProfile } from '../data/mockData';

export default function MyFarm() {
  const { location, setLocation } = useLocation();
  const { t } = useLanguage();
  const { currentFarm, saveFarm, backendAvailable, loading: farmLoading } = useFarm();

  const [form, setForm] = useState({
    name: farmProfile.name,
    country: farmProfile.country,
    region: 'Ayeyarwady',
    area: farmProfile.area,
    soil_type: farmProfile.soilType,
    current_crop: farmProfile.currentCrop,
    previous_crop: farmProfile.previousCrop,
    irrigation_method: farmProfile.irrigationMethod,
    planting_season: 'Monsoon',
  });

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState(null);

  // Load form from currentFarm when it's available
  useEffect(() => {
    if (currentFarm) {
      setForm({
        name: currentFarm.name || farmProfile.name,
        country: currentFarm.country || 'Myanmar',
        region: currentFarm.region || 'Ayeyarwady',
        area: currentFarm.area || farmProfile.area,
        soil_type: currentFarm.soil_type || farmProfile.soilType,
        current_crop: currentFarm.current_crop || farmProfile.currentCrop,
        previous_crop: currentFarm.previous_crop || farmProfile.previousCrop,
        irrigation_method: currentFarm.irrigation_method || farmProfile.irrigationMethod,
        planting_season: currentFarm.planting_season || 'Monsoon',
      });
    }
  }, [currentFarm]);

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setSaved(false);
    setSaveError(null);
  };

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    setSaveError(null);
    try {
      await saveFarm({
        ...form,
        latitude: location.lat,
        longitude: location.lon,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setForm({
      name: farmProfile.name,
      country: farmProfile.country,
      region: 'Ayeyarwady',
      area: farmProfile.area,
      soil_type: farmProfile.soilType,
      current_crop: farmProfile.currentCrop,
      previous_crop: farmProfile.previousCrop,
      irrigation_method: farmProfile.irrigationMethod,
      planting_season: 'Monsoon',
    });
    setSaved(false);
    setSaveError(null);
  };

  const regionForCountry = `Myanmar / ${form.region}`;

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Header */}
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('farmManagement')}</p>
      <h1 className="page-header mt-1">{t('betterPlan')}</h1>
      <p className="page-subtitle">{t('keepGrowing')}</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Left: Farm profile form */}
        <div className="lg:col-span-2">
          <div className="card">
            <h2 className="section-title mb-1">{t('farmProfile')}</h2>
            <p className="text-xs text-gray-400 dark:text-gray-500 mb-6">
              {backendAvailable
                ? 'Your farm data is saved to the FieldShift database.'
                : 'Backend not connected. Data saved in browser only.'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="label">{t('farmName')}</label>
                <input
                  type="text"
                  className="input-field"
                  value={form.name}
                  onChange={e => handleChange('name', e.target.value)}
                />
              </div>
              <div>
                <label className="label">{t('countryRegion')}</label>
                <select
                  className="select-field"
                  value={form.region}
                  onChange={e => handleChange('region', e.target.value)}
                >
                  <option value="Ayeyarwady">Myanmar / Ayeyarwady</option>
                  <option value="Mandalay">Myanmar / Mandalay</option>
                  <option value="Sagaing">Myanmar / Sagaing</option>
                  <option value="Bago">Myanmar / Bago</option>
                  <option value="Magway">Myanmar / Magway</option>
                  <option value="Yangon">Myanmar / Yangon</option>
                  <option value="Shan">Myanmar / Shan</option>
                </select>
              </div>
              <div>
                <label className="label">{t('farmLocation')}</label>
                <input
                  type="text"
                  className="input-field"
                  value={`${location.lat}°N, ${location.lon}°E`}
                  readOnly
                />
              </div>
              <div>
                <label className="label">{t('farmSize')}</label>
                <input
                  type="number"
                  className="input-field"
                  value={form.area}
                  onChange={e => handleChange('area', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div>
                <label className="label">{t('soilType')}</label>
                <select
                  className="select-field"
                  value={form.soil_type}
                  onChange={e => handleChange('soil_type', e.target.value)}
                >
                  <option>Clay loam</option>
                  <option>Sandy loam</option>
                  <option>Silt loam</option>
                  <option>Clay</option>
                  <option>Sandy</option>
                  <option>Loam</option>
                </select>
              </div>
              <div>
                <label className="label">{t('currentCrop')}</label>
                <select
                  className="select-field"
                  value={form.current_crop}
                  onChange={e => handleChange('current_crop', e.target.value)}
                >
                  <option>Rice</option>
                  <option>Wheat</option>
                  <option>Maize</option>
                  <option>Mung Bean</option>
                  <option>Soybean</option>
                  <option>Sesame</option>
                  <option>Groundnut</option>
                </select>
              </div>
              <div>
                <label className="label">{t('previousCrop')}</label>
                <select
                  className="select-field"
                  value={form.previous_crop}
                  onChange={e => handleChange('previous_crop', e.target.value)}
                >
                  <option>Rice</option>
                  <option>Wheat</option>
                  <option>Maize</option>
                  <option>Mung Bean</option>
                  <option>Soybean</option>
                  <option>Sesame</option>
                  <option>Groundnut</option>
                </select>
              </div>
              <div>
                <label className="label">{t('irrigationMethod')}</label>
                <select
                  className="select-field"
                  value={form.irrigation_method}
                  onChange={e => handleChange('irrigation_method', e.target.value)}
                >
                  <option>Canal irrigation</option>
                  <option>Rain-fed</option>
                  <option>Drip irrigation</option>
                  <option>Sprinkler</option>
                  <option>Tube well</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="label">{t('plantingSeason')}</label>
                <select
                  className="select-field"
                  value={form.planting_season}
                  onChange={e => handleChange('planting_season', e.target.value)}
                >
                  <option value="Monsoon">Monsoon • May–Oct</option>
                  <option value="Winter">Winter • Nov–Feb</option>
                  <option value="Summer">Summer • Mar–May</option>
                </select>
              </div>
            </div>

            {/* Save / Reset buttons */}
            <div className="flex items-center gap-3 mt-6">
              <button onClick={handleSave} disabled={saving} className="btn-primary">
                {saving ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</>
                ) : saved ? (
                  <><CheckCircle className="w-4 h-4" /> Saved!</>
                ) : (
                  <><Save className="w-4 h-4" /> {t('saveFarmProfile')}</>
                )}
              </button>
              <button onClick={handleReset} className="btn-outline">
                <RefreshCw className="w-4 h-4" />
                {t('updateForm')}
              </button>
            </div>

            {/* Error message */}
            {saveError && (
              <div className="flex items-center gap-2 mt-3 text-sm text-red-600 dark:text-red-400">
                <AlertCircle className="w-4 h-4" />
                {saveError}
              </div>
            )}

            <p className="text-xs text-gray-400 dark:text-gray-500 mt-3">
              {backendAvailable
                ? 'Farm data is stored in the SQLite database.'
                : 'Saved in browser session. Start the Flask backend for persistent storage.'}
            </p>
          </div>
        </div>

        {/* Right: Saved farm card + map */}
        <div className="space-y-6">
          {/* Saved farm summary */}
          <div className="card">
            <p className="text-xs font-medium text-gray-400 uppercase tracking-wider mb-2">
              ✦ {t('savedExampleFarm')}
            </p>
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">{form.name}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{regionForCountry}</p>
            <div className="flex items-center gap-3 mt-3 text-sm text-gray-600 dark:text-gray-400">
              <span>{form.area} ha</span>
              <span>•</span>
              <span>{form.soil_type}</span>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-700">
              <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1">Current season</p>
              <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{form.current_crop} / {form.planting_season}</p>
              <div className="text-xs text-gray-400 dark:text-gray-500 mt-2 space-y-0.5">
                <p>Previous crop: {form.previous_crop}</p>
                <p>Irrigation: {form.irrigation_method}</p>
              </div>
            </div>
            <Link to="/crop-rotation" className="btn-primary mt-4 w-full justify-center">
              {t('planNextSeason')} <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Interactive map */}
          <div>
            <p className="section-title mb-3">{t('pinFarmLocation')}</p>
            <InteractiveMap height="240px" showSearch={true} showGps={true} />
          </div>
        </div>
      </div>
    </div>
  );
}
