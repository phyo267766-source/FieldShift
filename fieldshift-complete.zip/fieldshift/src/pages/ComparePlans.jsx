import { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, Check, Loader2, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocation } from '../contexts/LocationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import { rotationApi } from '../api/client';
import { comparePlans as mockComparePlans } from '../data/mockData';

function PlanCard({ plan, isSelected, onSelect }) {
  const isRecommended = plan.recommended;

  return (
    <div
      className={`card cursor-pointer transition-all ${
        isRecommended
          ? 'border-2 border-forest ring-1 ring-forest/10'
          : 'hover:border-gray-300 dark:hover:border-gray-600'
      } ${isSelected ? 'bg-olive-light/30 dark:bg-brand-900/20' : ''}`}
      onClick={onSelect}
    >
      {/* Label */}
      <p className={`text-xs font-medium uppercase tracking-wider mb-2 ${
        isRecommended ? 'text-forest dark:text-brand-400' : 'text-gray-400'
      }`}>
        {isRecommended ? '✦ Recommended' : plan.label}
      </p>

      {/* Title */}
      <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">{plan.name}</h3>
      <p className="text-sm text-gray-500 mt-0.5">
        {plan.sequence.join(' → ')}
      </p>

      {/* Score */}
      <div className="mt-4 mb-4">
        <p className="text-4xl font-bold text-gray-900 dark:text-gray-100">
          {typeof plan.score === 'number' ? plan.score.toFixed(0) : plan.score}
          <span className="text-lg font-normal text-gray-400"> / 100</span>
        </p>
        <p className="text-xs text-gray-400 mt-0.5">Overall suitability score (illustrative)</p>
      </div>

      {/* Metrics */}
      <div className="space-y-3 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">Climate score</span>
          <span className="font-medium text-gray-900 dark:text-gray-200">{plan.climateScore || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">Water demand</span>
          <span className="font-medium text-gray-900 dark:text-gray-200">{plan.waterDemand || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">Soil health benefits</span>
          <span className="font-medium text-gray-900 dark:text-gray-200">{plan.soilHealth || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">Crop diversity</span>
          <span className="font-medium text-gray-900 dark:text-gray-200">{plan.cropDiversity || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">Sustainability risk</span>
          <span className="font-medium text-gray-900 dark:text-gray-200">{plan.sustainabilityRisk || '—'}</span>
        </div>
      </div>

      {/* Action */}
      <div className="mt-5">
        {isRecommended ? (
          <button className="btn-primary w-full justify-center">
            Select This Plan
          </button>
        ) : (
          <button className="btn-ghost w-full justify-center">
            View Details
          </button>
        )}
      </div>
    </div>
  );
}

export default function ComparePlans() {
  const [selected, setSelected] = useState('B');
  const { location } = useLocation();
  const { t } = useLanguage();
  const { currentFarm, backendAvailable } = useFarm();

  const [plans, setPlans] = useState(mockComparePlans);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isBackendData, setIsBackendData] = useState(false);
  const [bestPlanExplanation, setBestPlanExplanation] = useState(
    'A legume break balances familiar rice production with lower water demand and improved crop diversity. In this example, estimated water demand is 14% lower than continuous rice.'
  );

  useEffect(() => {
    if (currentFarm && backendAvailable) {
      fetchComparison();
    }
  }, [currentFarm, backendAvailable]);

  const fetchComparison = async () => {
    if (!currentFarm) return;
    setLoading(true);
    setError(null);

    try {
      const res = await rotationApi.compare({
        farm_id: currentFarm.id,
        current_crop: currentFarm.current_crop || 'Rice',
        previous_crop: currentFarm.previous_crop || 'Rice',
        soil_type: currentFarm.soil_type || 'Clay loam',
        season: currentFarm.planting_season || 'Monsoon',
        num_seasons: 3,
        water_availability: 'Moderate',
      });

      const data = res.data;

      if (data.plans && data.plans.length >= 2) {
        const labels = ['Plan A', 'Plan B', 'Plan C'];
        const ids = ['A', 'B', 'C'];
        const transformed = data.plans.map((p, i) => ({
          id: ids[i] || `P${i}`,
          label: labels[i] || `Plan ${i + 1}`,
          name: p.plan_name || p.name || labels[i],
          sequence: p.sequence || [],
          score: p.score || 0,
          recommended: i === 0, // First plan is the recommended one (highest score)
          climateScore: p.scores?.climate_suitability != null ? `${Math.round(p.scores.climate_suitability)}/100` : '—',
          waterDemand: p.water_demand || p.scores?.water_efficiency != null ? `${Math.round(p.scores.water_efficiency)}/100` : '—',
          soilHealth: p.scores?.soil_health != null ? `${Math.round(p.scores.soil_health)}/100` : '—',
          cropDiversity: p.scores?.diversity != null ? `${Math.round(p.scores.diversity)}/100` : '—',
          sustainabilityRisk: p.score >= 70 ? 'Low' : p.score >= 50 ? 'Moderate' : 'High',
        }));

        // Sort by score desc, mark best as recommended
        transformed.sort((a, b) => (b.score || 0) - (a.score || 0));
        transformed.forEach((p, i) => { p.recommended = i === 0; });

        setPlans(transformed);
        setSelected(transformed[0]?.id || 'A');
        setIsBackendData(true);

        if (data.plans[0]?.explanation) {
          setBestPlanExplanation(data.plans[0].explanation);
        }
      }
    } catch (err) {
      console.warn('Compare plans fetch failed:', err.message);
      setError('Could not fetch comparison from backend. Showing example plans.');
      setPlans(mockComparePlans);
      setIsBackendData(false);
    } finally {
      setLoading(false);
    }
  };

  const bestPlan = plans.find(p => p.recommended) || plans[0];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Header */}
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('threePaths')}</p>
      <h1 className="page-header mt-1">{t('compareNextCycle')}</h1>
      <p className="page-subtitle">{t('exploreTradeoffs')}</p>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mt-6 mb-8">
        <select className="select-field w-auto min-w-[160px]" defaultValue={currentFarm?.name || location.name}>
          <option>{currentFarm?.name || location.name}</option>
        </select>
        <select className="select-field w-auto min-w-[160px]" defaultValue="3-season comparison">
          <option>3-season comparison</option>
          <option>2-season comparison</option>
        </select>
        {!isBackendData && (
          <span className="text-[10px] font-medium text-red-600 bg-red-50 dark:bg-red-900/30 dark:text-red-400 px-2 py-0.5 rounded">
            DEMO DATA
          </span>
        )}
      </div>

      {error && (
        <div className="flex items-center gap-2 mb-4 text-sm text-amber-600 dark:text-amber-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center gap-2 py-12 text-gray-500">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Generating comparison plans...</span>
        </div>
      ) : (
        <>
          {/* Plan cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {plans.map(plan => (
              <PlanCard
                key={plan.id}
                plan={plan}
                isSelected={selected === plan.id}
                onSelect={() => setSelected(plan.id)}
              />
            ))}
          </div>

          {/* Why best plan */}
          <div className="card mb-6">
            <h3 className="section-title mb-2">
              Why {bestPlan?.name || 'Plan B'} stands out
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              {bestPlanExplanation}
            </p>
            <p className="text-xs text-gray-400 mt-2">
              Scores are illustrative. Based on rule-based scoring of crop diversity, soil health, water efficiency, and climate suitability.
            </p>
          </div>
        </>
      )}

      {/* Back to planner */}
      <Link to="/crop-rotation" className="btn-ghost">
        <ArrowLeft className="w-4 h-4" /> Return to rotation planner
      </Link>
    </div>
  );
}
