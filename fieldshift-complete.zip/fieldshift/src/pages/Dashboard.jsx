import { useState, useEffect } from 'react';
import { ArrowRight, AlertTriangle, Droplets, Thermometer, Sun, TrendingUp, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  BarChart, Bar, XAxis, Tooltip,
  ResponsiveContainer, AreaChart, Area,
} from 'recharts';
import StatCard from '../components/StatCard';
import DataSourceTag from '../components/DataSourceTag';
import InteractiveMap from '../components/InteractiveMap';
import { useLocation } from '../contexts/LocationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import { climateApi } from '../api/client';
import {
  dashboardStats, monthlyRainfall, monthlyTemperature,
  monthlySoilMoisture, monthlySolar, dataSourceLabels,
} from '../data/mockData';

function MiniBarChart({ data, color = '#2d5a2d', unit = '' }) {
  return (
    <ResponsiveContainer width="100%" height={100}>
      <BarChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
        <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }}
          formatter={(v) => [`${v}${unit}`, '']}
        />
        <Bar dataKey="value" fill={color} radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function MiniLineChart({ data, color = '#2d5a2d', unit = '' }) {
  return (
    <ResponsiveContainer width="100%" height={100}>
      <AreaChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.15} />
            <stop offset="95%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }}
          formatter={(v) => [`${v}${unit}`, '']}
        />
        <Area
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2}
          fill={`url(#grad-${color.replace('#', '')})`}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export default function Dashboard() {
  const { location } = useLocation();
  const { t } = useLanguage();
  const { currentFarm, backendAvailable } = useFarm();

  // Climate data state
  const [climateData, setClimateData] = useState(null);
  const [climateLoading, setClimateLoading] = useState(false);
  const [climateSource, setClimateSource] = useState(dataSourceLabels.power);
  const [demoMode, setDemoMode] = useState(true);

  // Chart data (from backend or fallback to mock)
  const [rainfallData, setRainfallData] = useState(monthlyRainfall);
  const [tempData, setTempData] = useState(monthlyTemperature);
  const [moistureData, setMoistureData] = useState(monthlySoilMoisture);
  const [solarData, setSolarData] = useState(monthlySolar);
  const [stats, setStats] = useState(dashboardStats);

  // Fetch climate data when farm is available
  useEffect(() => {
    if (currentFarm && currentFarm.id && backendAvailable) {
      fetchClimateData(currentFarm.id);
    }
  }, [currentFarm, backendAvailable]);

  async function fetchClimateData(farmId) {
    setClimateLoading(true);
    try {
      const data = await climateApi.getSummary(farmId);
      setClimateData(data);
      setClimateSource(data.source || dataSourceLabels.power);
      setDemoMode(data.demo_mode || false);

      // Update stats from summary
      const summary = data.summary || {};
      if (summary.temperature || summary.rainfall) {
        setStats({
          avgTemperature: summary.temperature?.average ?? dashboardStats.avgTemperature,
          totalRainfall: summary.rainfall?.total ?? dashboardStats.totalRainfall,
          soilMoisture: summary.humidity?.average ?? dashboardStats.soilMoisture,
          currentCrop: currentFarm?.current_crop || dashboardStats.currentCrop,
          cropSeason: currentFarm?.planting_season || dashboardStats.cropSeason,
          climateRisk: _riskLevel(data.risks),
          climateRiskNote: _riskNote(data.risks),
          tempChange: '',
          rainfallChange: '',
          soilMoistureNote: '',
        });
      }

      // Update chart data from seasonal patterns
      const patterns = data.seasonal_patterns || [];
      if (patterns.length > 0) {
        setRainfallData(patterns.map(p => ({
          month: p.month, value: p.total_rainfall ?? 0,
        })));
        setTempData(patterns.map(p => ({
          month: p.month, value: p.avg_temperature ?? 0,
        })));
        setSolarData(patterns.map(p => ({
          month: p.month, value: p.avg_solar ?? 0,
        })));
        // Estimate soil moisture from humidity (illustrative)
        setMoistureData(patterns.map(p => ({
          month: p.month,
          value: p.total_rainfall ? Math.min(50, Math.round(p.total_rainfall / 8)) : 0,
        })));
      }
    } catch (err) {
      console.warn('Climate fetch failed, using mock data:', err.message);
    } finally {
      setClimateLoading(false);
    }
  }

  function _riskLevel(risks) {
    if (!risks || risks.length === 0) return dashboardStats.climateRisk;
    const high = risks.find(r => r.level === 'High');
    if (high) return 'High';
    const mod = risks.find(r => r.level === 'Moderate');
    if (mod) return 'Moderate';
    return 'Low';
  }

  function _riskNote(risks) {
    if (!risks || risks.length === 0) return dashboardStats.climateRiskNote;
    const high = risks.find(r => r.level === 'High');
    if (high) return high.risk;
    const mod = risks.find(r => r.level === 'Moderate');
    if (mod) return mod.risk;
    return 'No major risks detected';
  }

  const farmName = currentFarm?.name || location.name;
  const farmRegion = currentFarm?.region || location.region || 'Ayeyarwady';

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Page header */}
      <div className="mb-1">
        <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('yourFarmInFocus')}</p>
        <h1 className="page-header mt-1">{t('growSmarter')}</h1>
        <p className="page-subtitle">{t('transformSatellite')}</p>
      </div>

      {/* Farm selector & CTA */}
      <div className="flex flex-wrap items-center gap-3 mt-5 mb-6">
        <select className="select-field w-auto min-w-[160px]" defaultValue={farmName}>
          <option>{farmName}</option>
        </select>
        <select className="select-field w-auto min-w-[140px]" defaultValue="May–Oct 2026">
          <option>May–Oct 2026</option>
        </select>
        <Link to="/my-farm" className="btn-primary">
          {t('analyzeMyFarm')} <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      {/* Status banner */}
      <div className="bg-olive-light dark:bg-brand-900/30 rounded-lg px-4 py-3 mb-6">
        <p className="text-sm font-semibold text-forest dark:text-brand-300">
          {demoMode ? `${t('demoWorkspace')} • ` : ''}Myanmar / {farmRegion}
          {backendAvailable && !demoMode && (
            <span className="ml-2 text-xs text-green-600 dark:text-green-400">● Backend connected</span>
          )}
        </p>
        <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">
          {demoMode ? t('illustrativeClimate') : `Climate data from ${climateSource}`}
        </p>
      </div>

      {/* Loading indicator */}
      {climateLoading && (
        <div className="flex items-center gap-2 mb-4 text-sm text-gray-500">
          <Loader2 className="w-4 h-4 animate-spin" />
          Fetching climate data from NASA POWER...
        </div>
      )}

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-6 mb-8">
        <StatCard
          label={t('avgTemperature')}
          value={`${stats.avgTemperature} °C`}
          note={stats.tempChange}
        />
        <StatCard
          label={t('totalRainfall')}
          value={`${stats.totalRainfall} mm`}
          note={stats.rainfallChange}
        />
        <StatCard
          label={t('soilMoisture')}
          value={`${stats.soilMoisture} %`}
          note={stats.soilMoistureNote}
        />
        <StatCard
          label={t('currentCrop')}
          value={stats.currentCrop}
          note={stats.cropSeason}
        />
        <StatCard
          label={t('climateRisk')}
          value={stats.climateRisk}
          note={stats.climateRiskNote}
          className="col-span-2 md:col-span-1"
        />
      </div>

      {/* Map + Seasonal Tip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <h2 className="section-title mb-3">{t('yourFarmFromAbove')}</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{t('exploreRegion')}</p>
          <InteractiveMap height="360px" />
        </div>

        {/* Seasonal tip card */}
        <div className="bg-forest dark:bg-brand-800 text-white rounded-xl p-6 flex flex-col justify-between">
          <div>
            <p className="text-xs font-medium text-brand-200 uppercase tracking-wider mb-2">
              ✦ {t('healthyNextSeason')}
            </p>
            <h3 className="text-xl font-bold mb-3">
              {t('giveYourSoil')}
            </h3>
            <p className="text-sm text-white/80 leading-relaxed">
              {t('legumeSeason')}
            </p>
            <div className="flex items-center gap-2 mt-4 text-sm font-medium text-white/90">
              <span>Rice</span>
              <ArrowRight className="w-3 h-3" />
              <span>Mung Bean</span>
              <ArrowRight className="w-3 h-3" />
              <span>Rice</span>
            </div>
          </div>
          <div className="mt-6">
            <Link to="/crop-rotation" className="bg-white text-forest px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-100 transition-colors inline-flex items-center gap-2 w-full justify-center">
              {t('exploreRotation')} <ArrowRight className="w-4 h-4" />
            </Link>
            <p className="text-[10px] text-white/50 mt-2 text-center">
              Example guidance, not a yield guarantee.
            </p>
          </div>
        </div>
      </div>

      {/* Trend Charts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="card">
          <div className="flex items-center gap-2 mb-1">
            <Droplets className="w-4 h-4 text-blue-500" />
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('rainfallTrend')}</p>
          </div>
          <p className="stat-value mb-3">{stats.totalRainfall} mm</p>
          <MiniBarChart data={rainfallData} color="#3b82f6" unit=" mm" />
          <DataSourceTag source={demoMode ? dataSourceLabels.power : climateSource} />
        </div>

        <div className="card">
          <div className="flex items-center gap-2 mb-1">
            <Thermometer className="w-4 h-4 text-orange-500" />
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('temperatureTrend')}</p>
          </div>
          <p className="stat-value mb-3">{stats.avgTemperature} °C</p>
          <MiniBarChart data={tempData} color="#22c55e" unit="°C" />
          <DataSourceTag source={demoMode ? dataSourceLabels.power : climateSource} />
        </div>

        <div className="card">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-teal-500" />
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('soilMoisture')}</p>
          </div>
          <p className="stat-value mb-3">{stats.soilMoisture} %</p>
          <MiniLineChart data={moistureData} color="#14b8a6" unit="%" />
          <DataSourceTag source={demoMode ? 'Locally estimated via formula, based on POWER data' : 'Estimated from NASA POWER humidity data'} />
        </div>

        <div className="card">
          <div className="flex items-center gap-2 mb-1">
            <Sun className="w-4 h-4 text-amber-500" />
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('solarRadiation')}</p>
          </div>
          <p className="stat-value mb-3">
            {solarData.length > 0 ? (solarData.reduce((s, d) => s + d.value, 0) / solarData.length).toFixed(1) : '4.8'} kWh/m²
          </p>
          <MiniLineChart data={solarData} color="#f59e0b" unit=" kWh" />
          <DataSourceTag source={demoMode ? dataSourceLabels.power : climateSource} />
        </div>
      </div>

      {/* Heat stress alert */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg px-4 py-3 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">
            ⚠ {t('heatStressWatch')}
          </p>
          <p className="text-sm text-amber-700 dark:text-amber-400 mt-0.5">
            {t('warmDays')}
          </p>
          <Link to="/climate-insights" className="btn-ghost text-amber-700 dark:text-amber-300 mt-2">
            {t('reviewClimateRisks')} <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </div>
  );
}
