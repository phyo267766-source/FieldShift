import { useState, useEffect } from 'react';
import { ArrowRight, Loader2 } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  AreaChart, Area, CartesianGrid,
} from 'recharts';
import DataSourceTag from '../components/DataSourceTag';
import { useLocation } from '../contexts/LocationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import { climateApi } from '../api/client';
import {
  monthlyRainfall, monthlyTemperature, monthlySoilMoisture,
  monthlySolar, seasonalPatterns, climateRisks, farmProfile,
  dataSourceLabels,
} from '../data/mockData';

const riskColors = {
  Low: 'text-green-600 bg-green-50 dark:bg-green-900/30 dark:text-green-400',
  Moderate: 'text-amber-600 bg-amber-50 dark:bg-amber-900/30 dark:text-amber-400',
  High: 'text-red-600 bg-red-50 dark:bg-red-900/30 dark:text-red-400',
};

const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function ChartCard({ title, value, unit, data, type = 'bar', color = '#2d5a2d', dataSource, note }) {
  return (
    <div className="card">
      <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-1">{title}</h3>
      <p className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-4">
        {value} <span className="text-base font-normal text-gray-500">{unit}</span>
      </p>
      <ResponsiveContainer width="100%" height={140}>
        {type === 'bar' ? (
          <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }} />
            <Bar dataKey="value" fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        ) : (
          <AreaChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id={`area-${title.replace(/\s/g, '')}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.15} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }} />
            <Area type="monotone" dataKey="value" stroke={color} strokeWidth={2} fill={`url(#area-${title.replace(/\s/g, '')})`} />
          </AreaChart>
        )}
      </ResponsiveContainer>
      <DataSourceTag source={dataSource} />
      <p className="text-[10px] text-gray-400">{note}</p>
    </div>
  );
}

export default function ClimateInsights() {
  const [view, setView] = useState('Monthly');
  const { location } = useLocation();
  const { t } = useLanguage();
  const { currentFarm, backendAvailable } = useFarm();

  // Climate data states
  const [loading, setLoading] = useState(false);
  const [dataSource, setDataSource] = useState('DEMO DATA');
  const [demoMode, setDemoMode] = useState(true);

  // Chart data
  const [rainfallData, setRainfallData] = useState(monthlyRainfall);
  const [temperatureData, setTemperatureData] = useState(monthlyTemperature);
  const [moistureData, setMoistureData] = useState(monthlySoilMoisture);
  const [solarData, setSolarData] = useState(monthlySolar);

  // Summary values
  const [totalRainfall, setTotalRainfall] = useState('842');
  const [avgTemp, setAvgTemp] = useState('28.6');
  const [avgMoisture, setAvgMoisture] = useState('34');
  const [avgSolar, setAvgSolar] = useState('4.8');

  // Risk + seasonal
  const [risks, setRisks] = useState(climateRisks);
  const [seasons, setSeasons] = useState(seasonalPatterns);

  useEffect(() => {
    if (currentFarm && backendAvailable) {
      fetchClimateHistory(currentFarm.id);
    }
  }, [currentFarm, backendAvailable]);

  const fetchClimateHistory = async (farmId) => {
    setLoading(true);
    try {
      // Fetch monthly history from backend
      const historyRes = await climateApi.getHistory(farmId);
      const history = historyRes.data;

      if (history && history.monthly_data) {
        const monthly = history.monthly_data;

        // Build chart arrays from monthly data
        const rainArr = [];
        const tempArr = [];
        const solarArr = [];
        const moistArr = [];

        Object.entries(monthly).forEach(([monthKey, vals]) => {
          const monthNum = parseInt(monthKey.toString().slice(-2)) - 1;
          const label = MONTH_NAMES[monthNum] || monthKey;
          if (vals.PRECTOTCORR != null) rainArr.push({ month: label, value: Math.round(vals.PRECTOTCORR * 30 * 10) / 10 });
          if (vals.T2M != null) tempArr.push({ month: label, value: Math.round(vals.T2M * 10) / 10 });
          if (vals.ALLSKY_SFC_SW_DWN != null) solarArr.push({ month: label, value: Math.round(vals.ALLSKY_SFC_SW_DWN * 10) / 10 });
          // Estimate soil moisture from humidity if available
          if (vals.RH2M != null) moistArr.push({ month: label, value: Math.round(vals.RH2M * 0.5 * 10) / 10 });
        });

        if (rainArr.length > 0) setRainfallData(rainArr);
        if (tempArr.length > 0) setTemperatureData(tempArr);
        if (solarArr.length > 0) setSolarData(solarArr);
        if (moistArr.length > 0) setMoistureData(moistArr);

        // Summary values
        if (rainArr.length > 0) setTotalRainfall(Math.round(rainArr.reduce((s, d) => s + d.value, 0)).toString());
        if (tempArr.length > 0) setAvgTemp((tempArr.reduce((s, d) => s + d.value, 0) / tempArr.length).toFixed(1));
        if (solarArr.length > 0) setAvgSolar((solarArr.reduce((s, d) => s + d.value, 0) / solarArr.length).toFixed(1));
        if (moistArr.length > 0) setAvgMoisture(Math.round(moistArr.reduce((s, d) => s + d.value, 0) / moistArr.length).toString());

        setDataSource(history.source === 'demo' ? 'DEMO DATA' : 'NASA POWER');
        setDemoMode(history.source === 'demo');
      }

      // Also fetch climate summary for risks
      try {
        const summaryRes = await climateApi.getSummary(farmId);
        if (summaryRes.data?.risks) {
          setRisks(summaryRes.data.risks.map(r => ({
            risk: r.risk,
            level: r.level,
            description: r.description || '',
          })));
        }
      } catch { /* keep default risks */ }

    } catch (err) {
      console.warn('Climate history fetch failed, using mock data:', err.message);
      setDemoMode(true);
      setDataSource('DEMO DATA');
    } finally {
      setLoading(false);
    }
  };

  const riskDescriptions = {
    'Drought risk': 'Adequate rainfall and irrigation supply.',
    'Heavy rainfall risk': 'Track flood-prone areas for your production window.',
    'Heat stress': 'Cover heat-sensitive phases for soil and crop.',
    'Water availability': 'Reasonably nearby; stable conditions for settling.',
    'Seasonal planting risk': 'Confirm local planting dates with your extension office.',
  };

  const sourceLabel = demoMode ? 'DEMO DATA' : 'NASA POWER';
  const noteText = demoMode
    ? 'Sample values. Start the Flask backend with NASA API access for real data.'
    : `Source: NASA POWER API. Monthly data for ${currentFarm?.name || 'selected farm'}.`;

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Header */}
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('earthObservations')}</p>
      <h1 className="page-header mt-1">{t('understandClimate')}</h1>
      <p className="page-subtitle">{t('seasonalContext')}</p>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mt-6 mb-4">
        <select className="select-field w-auto min-w-[160px]" defaultValue={location.name}>
          <option>{location.name}</option>
        </select>
        <select className="select-field w-auto min-w-[140px]" defaultValue="May–Oct 2026">
          <option>May–Oct 2026</option>
        </select>
        <div className="flex border border-gray-300 dark:border-gray-600 rounded-lg overflow-hidden">
          {['Daily', 'Monthly'].map(v => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                view === v
                  ? 'bg-forest dark:bg-brand-500 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              {v === 'Daily' ? t('daily') : t('monthly')}
            </button>
          ))}
        </div>
      </div>

      {/* Data source tags */}
      <div className="flex flex-wrap items-center gap-2 mb-2">
        <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
          demoMode ? 'text-red-600 bg-red-50 dark:bg-red-900/30 dark:text-red-400' : 'text-green-600 bg-green-50 dark:bg-green-900/30 dark:text-green-400'
        }`}>
          {sourceLabel}
        </span>
        {!demoMode && (
          <span className="text-[10px] font-medium text-green-600 bg-green-50 dark:bg-green-900/30 dark:text-green-400 px-2 py-0.5 rounded">
            ● Backend connected
          </span>
        )}
      </div>
      <p className="text-xs text-gray-400 mb-6">
        {demoMode
          ? 'These sample values are not retrieved from NASA. Start the backend for real data.'
          : `Data from NASA POWER API via FieldShift backend. Farm: ${currentFarm?.name || 'N/A'}.`}
      </p>

      {/* Loading state */}
      {loading && (
        <div className="flex items-center justify-center gap-2 py-8 text-gray-500">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Fetching climate data...</span>
        </div>
      )}

      {/* Charts Grid */}
      {!loading && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <ChartCard
              title="Historical Rainfall Analysis"
              value={totalRainfall}
              unit="mm"
              data={rainfallData}
              color="#2d5a2d"
              dataSource={sourceLabel}
              note={noteText}
            />
            <ChartCard
              title="Temperature Trends"
              value={avgTemp}
              unit="°C"
              data={temperatureData}
              type="bar"
              color="#22c55e"
              dataSource={sourceLabel}
              note={noteText}
            />
            <ChartCard
              title="Soil Moisture Conditions"
              value={avgMoisture}
              unit="%"
              data={moistureData}
              type="bar"
              color="#3b82f6"
              dataSource={demoMode ? 'DEMO DATA' : 'Estimated from NASA POWER humidity data'}
              note={noteText}
            />
            <ChartCard
              title="Solar Radiation"
              value={avgSolar}
              unit="kWh/m²/day"
              data={solarData}
              type="line"
              color="#f59e0b"
              dataSource={sourceLabel}
              note={noteText}
            />
          </div>

          {/* Bottom section: Seasonal + Risk */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Seasonal patterns */}
            <div className="card">
              <h3 className="section-title mb-4">Seasonal Climate Patterns</h3>
              <div className="space-y-4">
                {seasons.map((s, i) => (
                  <div key={i} className="border-l-2 border-brand-300 dark:border-brand-500 pl-4">
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{s.season}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{s.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Climate risk assessment */}
            <div className="card">
              <h3 className="section-title mb-4">Climate Risk Assessment</h3>
              <div className="space-y-3">
                {risks.map((r, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-gray-50 dark:border-gray-700 last:border-0">
                    <div className="flex items-center gap-2 shrink-0 pt-0.5">
                      <span className={`inline-block w-2 h-2 rounded-full ${
                        r.level === 'Low' ? 'bg-green-500' : r.level === 'Moderate' ? 'bg-amber-500' : 'bg-red-500'
                      }`} />
                      <span className={`text-xs font-medium px-2 py-0.5 rounded ${riskColors[r.level]}`}>
                        {r.risk} • {r.level}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {r.description || riskDescriptions[r.risk] || ''}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
