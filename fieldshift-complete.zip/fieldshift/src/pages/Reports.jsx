import { useState, useEffect } from 'react';
import { FileText, Download, Printer, Loader2, AlertCircle } from 'lucide-react';
import StatCard from '../components/StatCard';
import { useLanguage } from '../contexts/LanguageContext';
import { useFarm } from '../contexts/FarmContext';
import { reportApi } from '../api/client';
import { reportData as mockReportData } from '../data/mockData';

export default function Reports() {
  const [activeTab, setActiveTab] = useState('generate');
  const { t } = useLanguage();
  const { currentFarm, backendAvailable } = useFarm();

  const [report, setReport] = useState(mockReportData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isBackendReport, setIsBackendReport] = useState(false);

  const generateReport = async () => {
    if (!currentFarm || !backendAvailable) {
      setReport(mockReportData);
      setIsBackendReport(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await reportApi.generate({ farm_id: currentFarm.id });
      const data = res.data;

      // Transform backend response to match UI structure
      const transformed = {
        title: data.title || `${currentFarm.name} – Farm Report`,
        location: data.farm?.region
          ? `${data.farm.region}, ${data.farm.country || 'Myanmar'}`
          : mockReportData.location,
        period: data.period || mockReportData.period,
        stats: {
          avgTemp: data.climate_summary?.temperature?.avg
            ? `${data.climate_summary.temperature.avg.toFixed(1)}°C`
            : mockReportData.stats.avgTemp,
          totalRainfall: data.climate_summary?.rainfall?.total
            ? `${Math.round(data.climate_summary.rainfall.total)} mm`
            : mockReportData.stats.totalRainfall,
          soilMoisture: data.climate_summary?.humidity?.avg
            ? `${Math.round(data.climate_summary.humidity.avg * 0.5)}%`
            : mockReportData.stats.soilMoisture,
          climateRisk: data.climate_summary?.risk_level || mockReportData.stats.climateRisk,
        },
        recommendations: data.recommendations || mockReportData.recommendations,
        planComparison: data.plan_comparison || mockReportData.planComparison,
      };

      setReport(transformed);
      setIsBackendReport(true);
    } catch (err) {
      console.warn('Report generation failed:', err.message);
      setError('Could not generate report from backend. Showing example report.');
      setReport(mockReportData);
      setIsBackendReport(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentFarm && backendAvailable) {
      generateReport();
    }
  }, [currentFarm, backendAvailable]);

  const barData = (report.planComparison || []).map(p => ({
    name: p.name,
    score: p.score,
  }));

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* Header */}
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{t('turnInsight')}</p>
      <h1 className="page-header mt-1">{t('yourFarmReport')}</h1>
      <p className="page-subtitle">{t('practicalSummary')}</p>

      {/* Action tabs */}
      <div className="flex items-center gap-2 mt-6 mb-6">
        <button
          onClick={() => { setActiveTab('generate'); generateReport(); }}
          className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors inline-flex items-center gap-2 ${
            activeTab === 'generate'
              ? 'bg-forest text-white'
              : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
          }`}
        >
          <FileText className="w-4 h-4" />
          {t('generateReport')}
        </button>
        <button
          onClick={() => setActiveTab('download')}
          className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors inline-flex items-center gap-2 ${
            activeTab === 'download'
              ? 'bg-forest text-white'
              : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
          }`}
        >
          <Download className="w-4 h-4" />
          {t('downloadPdf')}
        </button>
        <button
          onClick={() => { setActiveTab('print'); window.print(); }}
          className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-colors inline-flex items-center gap-2 ${
            activeTab === 'print'
              ? 'bg-forest text-white'
              : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
          }`}
        >
          <Printer className="w-4 h-4" />
          {t('printReport')}
        </button>

        {!isBackendReport && (
          <span className="text-[10px] font-medium text-red-600 bg-red-50 dark:bg-red-900/30 dark:text-red-400 px-2 py-0.5 rounded ml-2">
            DEMO DATA
          </span>
        )}
      </div>

      {error && (
        <div className="flex items-center gap-2 mb-4 text-sm text-amber-600 dark:text-amber-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center gap-2 py-12 text-gray-500">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Generating report...</span>
        </div>
      ) : (
        <div className="card border-t-4 border-t-forest dark:border-t-brand-400">
          {/* Report header */}
          <div className="mb-6">
            <p className="text-xs font-medium text-forest dark:text-brand-400 uppercase tracking-wider">
              FieldShift / Farm Climate Summary
            </p>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">{report.title}</h2>
            <p className="text-sm text-gray-500 mt-0.5">{report.location}</p>
            <p className="text-xs text-gray-400 mt-1">{report.period}</p>
          </div>

          {/* KPI Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 border-y border-gray-100 dark:border-gray-700 mb-6">
            <StatCard label="Average temperature" value={report.stats.avgTemp} />
            <StatCard label="Total rainfall" value={report.stats.totalRainfall} />
            <StatCard label="Soil moisture" value={report.stats.soilMoisture} />
            <StatCard label="Climate risk" value={report.stats.climateRisk} />
          </div>

          {/* Recommendations grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {Object.values(report.recommendations || {}).map((rec, i) => (
              <div key={i} className="border border-gray-100 dark:border-gray-700 rounded-lg p-4">
                <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">{rec.title}</p>
                <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {rec.plan || rec.value}
                </p>
                <p className="text-sm text-gray-500 mt-1">{rec.note}</p>
              </div>
            ))}
          </div>

          {/* Plan comparison bars */}
          {barData.length > 0 && (
            <div>
              <h3 className="section-title mb-4">Plan Comparison Charts</h3>
              <div className="space-y-3">
                {barData.map((d, i) => (
                  <div key={d.name} className="flex items-center gap-3">
                    <span className="text-sm text-gray-600 dark:text-gray-400 w-32 shrink-0">{d.name}</span>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-6 relative overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          i === 0 ? 'bg-forest' : 'bg-gray-400 dark:bg-gray-500'
                        }`}
                        style={{ width: `${d.score}%` }}
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-medium text-gray-600 dark:text-gray-300">
                        {typeof d.score === 'number' ? d.score.toFixed(0) : d.score} / 100
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-400 mt-3">
                Illustrative suitability scores; not calibrated nor guaranteed.
              </p>
            </div>
          )}

          {/* Footer disclaimer */}
          <div className="mt-8 pt-4 border-t border-gray-100 dark:border-gray-700">
            <p className="text-xs text-gray-400">
              DATA & LIMITATIONS • {isBackendReport ? 'NASA POWER data via FieldShift backend.' : 'Demo values.'} Recommendations are illustrative. Consult local expertise before acting.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
