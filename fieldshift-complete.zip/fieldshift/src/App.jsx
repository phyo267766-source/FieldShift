import { Routes, Route } from 'react-router-dom';
import { LocationProvider } from './contexts/LocationContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { FarmProvider } from './contexts/FarmContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Dashboard from './pages/Dashboard';
import MyFarm from './pages/MyFarm';
import ClimateInsights from './pages/ClimateInsights';
import CropRotation from './pages/CropRotation';
import ComparePlans from './pages/ComparePlans';
import Reports from './pages/Reports';

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <LocationProvider>
          <FarmProvider>
            <div className="min-h-screen flex flex-col bg-cream dark:bg-gray-900 transition-colors">
              <Navbar />
              <main className="flex-1">
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/my-farm" element={<MyFarm />} />
                  <Route path="/climate-insights" element={<ClimateInsights />} />
                  <Route path="/crop-rotation" element={<CropRotation />} />
                  <Route path="/compare-plans" element={<ComparePlans />} />
                  <Route path="/reports" element={<Reports />} />
                </Routes>
              </main>
              <Footer />
            </div>
          </FarmProvider>
        </LocationProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
