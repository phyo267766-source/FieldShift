/**
 * FieldShift API Client
 * Centralized API communication with the Flask backend.
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:5000';

/**
 * Make an API request with error handling.
 */
async function apiRequest(path, options = {}) {
  const url = `${API_BASE}${path}`;
  const config = {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  };

  try {
    const response = await fetch(url, config);
    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(
        data.error || `Request failed with status ${response.status}`,
        response.status,
        data.details || null
      );
    }

    return data;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    // Network error — backend probably not running
    throw new ApiError(
      'Could not connect to the FieldShift backend. Is the Flask server running?',
      0,
      null
    );
  }
}

class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

// ── Farm API ────────────────────────────────────────────────────────────────

export const farmApi = {
  getAll: () => apiRequest('/api/farms'),

  getById: (id) => apiRequest(`/api/farms/${id}`),

  create: (farmData) =>
    apiRequest('/api/farms', {
      method: 'POST',
      body: JSON.stringify(farmData),
    }),

  update: (id, farmData) =>
    apiRequest(`/api/farms/${id}`, {
      method: 'PUT',
      body: JSON.stringify(farmData),
    }),

  delete: (id) =>
    apiRequest(`/api/farms/${id}`, { method: 'DELETE' }),
};

// ── Climate API ─────────────────────────────────────────────────────────────

export const climateApi = {
  getFarmClimate: (farmId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/api/climate/farm/${farmId}${query ? `?${query}` : ''}`);
  },

  getHistory: (farmId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/api/climate/history/${farmId}${query ? `?${query}` : ''}`);
  },

  getSummary: (farmId) => apiRequest(`/api/climate/summary/${farmId}`),
};

// ── Rotation API ────────────────────────────────────────────────────────────

export const rotationApi = {
  generate: (data) =>
    apiRequest('/api/rotation/generate', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  compare: (data) =>
    apiRequest('/api/rotation/compare', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getFarmPlans: (farmId) => apiRequest(`/api/rotation/farm/${farmId}`),

  getPlan: (planId) => apiRequest(`/api/rotation/${planId}`),

  selectPlan: (planId) =>
    apiRequest(`/api/rotation/${planId}/select`, { method: 'PUT' }),
};

// ── Report API ──────────────────────────────────────────────────────────────

export const reportApi = {
  create: (data) =>
    apiRequest('/api/reports', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getFarmReports: (farmId) => apiRequest(`/api/reports/farm/${farmId}`),

  getReport: (reportId) => apiRequest(`/api/reports/${reportId}`),
};

export { ApiError };
export default { farmApi, climateApi, rotationApi, reportApi };
